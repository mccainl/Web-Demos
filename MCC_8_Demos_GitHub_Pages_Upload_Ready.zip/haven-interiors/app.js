
const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
const escapeHtml=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const store={load(key,fallback){try{return JSON.parse(localStorage.getItem(key))??fallback}catch{return fallback}},save(key,val){localStorage.setItem(key,JSON.stringify(val))}};
const fmtDate=d=>{try{return new Date(d+'T12:00:00').toLocaleDateString('nl-NL',{day:'numeric',month:'short',year:'numeric'})}catch{return d}};
const nextISO=(days=1)=>{const d=new Date();d.setDate(d.getDate()+days);return d.toISOString().slice(0,10)};
const uid=()=>`${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`;
function say(text,isError=false){const box=$('#feedback');if(!box)return;box.textContent=text;box.classList.toggle('error',isError);box.hidden=false;window.clearTimeout(say.timer);say.timer=setTimeout(()=>{box.hidden=true},8000);box.scrollIntoView({block:'nearest',behavior:'smooth'})}
function setView(view){const owner=view==='owner';$('#owner-screen').hidden=!owner;$('#public-screen').hidden=owner;$$('[data-view]').forEach(b=>{b.classList.toggle('active',b.dataset.view===view);b.setAttribute('aria-pressed',String(b.dataset.view===view))});window.scrollTo({top:0,behavior:'instant'});if(owner)renderOwner();}
$$('[data-view]').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.view)));
$('#reset-demo').addEventListener('click',()=>{if(confirm('Alle demo-invoer op dit apparaat wissen?')){localStorage.removeItem(KEY);initialize();say('Demo teruggezet naar de beginstand.')}});
function appendRows(root,items,callback){if(!items.length){root.innerHTML='<div class="empty">Nog geen aanvragen. Probeer de bezoekerskant.</div>';return}root.innerHTML=items.map(callback).join('')}
function validateEmail(v){return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v).trim())}


const KEY='mcc-haven-interiors-v1';
const initial=()=>({items:[
{id:'living',name:'Living softly',category:'Wonen',img:'living.webp',desc:'Tactiele texturen en rustige tinten.',live:true},
{id:'dining',name:'Gather around',category:'Eten',img:'dining.webp',desc:'Een tafel als het hart van het huis.',live:true},
{id:'kitchen',name:'Calm in the kitchen',category:'Koken',img:'kitchen.webp',desc:'Warme steen en eenvoudige rituelen.',live:true},
{id:'bedroom',name:'A softer morning',category:'Slapen',img:'bedroom.webp',desc:'Licht, linnen en stille ochtenden.',live:true}
],saved:[],enquiries:[]});let db,category='Alles';
function initialize(){db=store.load(KEY,initial());renderPublic();renderOwner()}
function renderPublic(){const items=db.items.filter(x=>x.live&&(category==='Alles'||x.category===category));$('#collection-grid').innerHTML=items.length?items.map(i=>`<article class="tile"><img src="assets/${i.img}" alt="Interieurconcept ${escapeHtml(i.name)}" loading="lazy"><div class="tile-content"><span class="product-tag">${escapeHtml(i.category)} / Collectie 2026</span><h3>${escapeHtml(i.name)}</h3><p>${escapeHtml(i.desc)}</p><button type="button" data-save="${i.id}" aria-pressed="${db.saved.includes(i.id)}">${db.saved.includes(i.id)?'♥ Bewaard in moodboard':'♡ Bewaar op moodboard'} ↗</button></div></article>`).join(''):'<p>Er zijn momenteel geen collecties in deze categorie.</p>';
 $$('[data-save]').forEach(b=>b.onclick=()=>{const id=b.dataset.save;db.saved=db.saved.includes(id)?db.saved.filter(x=>x!==id):[...db.saved,id];store.save(KEY,db);renderPublic();renderOwner()});
 $('#mood-count').textContent=`${db.saved.length} bewaarde items`;
 $('#chosen-mood').textContent=db.saved.length?`Jouw moodboard: ${db.saved.map(id=>db.items.find(i=>i.id===id)?.name).filter(Boolean).join(', ')}.`:'Jouw moodboard is nog leeg. Je kunt ook zonder selectie een aanvraag indienen.';
}
$$('[data-category]').forEach(b=>b.onclick=()=>{category=b.dataset.category;$$('[data-category]').forEach(t=>t.classList.toggle('selected',t===b));renderPublic()});
$('#haven-form').onsubmit=e=>{e.preventDefault();const name=$('#haven-name').value.trim(),email=$('#haven-email').value.trim(),message=$('#haven-message').value.trim();if(!name||!validateEmail(email)||message.length<10){say('Vul je naam, geldig e-mailadres en minimaal 10 tekens in.',true);return}db.enquiries.unshift({id:uid(),name,email,room:$('#haven-room').value,message,saved:[...db.saved],status:'nieuw'});store.save(KEY,db);renderOwner();say('Je conceptaanvraag is toegevoegd aan het eigenaarsoverzicht. Er is niets verzonden.');e.target.reset();};
function renderOwner(){
 $('#haven-enquiries').textContent=db.enquiries.filter(e=>e.status==='nieuw').length;
 $('#haven-listed').textContent=db.items.filter(i=>i.live).length;
 $('#haven-saved').textContent=db.saved.length;
 $('#enquiry-list').innerHTML=db.enquiries.length?db.enquiries.map(e=>`<div class="scenario"><strong>${escapeHtml(e.name)}</strong> <span class="state ${e.status==='nieuw'?'warn':''}">${escapeHtml(e.status)}</span><p>${escapeHtml(e.room)} · ${escapeHtml(e.message)}</p><p class="panel-note">Moodboard: ${e.saved.map(id=>escapeHtml(db.items.find(i=>i.id===id)?.name||'')).join(', ')||'Geen selectie'}<br>${escapeHtml(e.email)}</p>${e.status==='nieuw'?`<button type="button" class="outline" data-enquiry="${e.id}">Markeer opgevolgd</button>`:''}</div>`).join(''):'<div class="empty">Nog geen klantvragen. Probeer de bezoekerskant.</div>';
 $('#collection-manager').innerHTML=db.items.map(i=>`<div class="scenario" style="display:flex;align-items:center;gap:14px"><img src="assets/${i.img}" alt="" style="width:75px;height:75px;object-fit:cover"><div style="flex:1"><strong>${escapeHtml(i.name)}</strong><p style="margin:4px 0">${i.live?'Live':'Verborgen'}</p></div><button type="button" class="outline" data-toggle="${i.id}">${i.live?'Verberg':'Toon'}</button></div>`).join('');
 $$('[data-enquiry]').forEach(b=>b.onclick=()=>{db.enquiries.find(e=>e.id===b.dataset.enquiry).status='opgevolgd';store.save(KEY,db);renderOwner();say('Aanvraag als opgevolgd gemarkeerd.')});
 $$('[data-toggle]').forEach(b=>b.onclick=()=>{const item=db.items.find(i=>i.id===b.dataset.toggle);item.live=!item.live;store.save(KEY,db);renderOwner();renderPublic()});
}
initialize();
