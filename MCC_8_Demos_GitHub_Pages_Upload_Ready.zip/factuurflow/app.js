
const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
const escapeHtml=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const store={load(key,fallback){try{return JSON.parse(localStorage.getItem(key))??fallback}catch{return fallback}},save(key,val){localStorage.setItem(key,JSON.stringify(val))}};
const fmtDate=d=>{try{return new Date(d+'T12:00:00').toLocaleDateString('nl-NL',{day:'numeric',month:'short',year:'numeric'})}catch{return d}};
const nextISO=(days=1)=>{const d=new Date();d.setDate(d.getDate()+days);return d.toISOString().slice(0,10)};
const uid=()=>`${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`;
function say(text,isError=false){const box=$('#feedback');if(!box)return;box.textContent=text;box.classList.toggle('error',isError);box.hidden=false;window.clearTimeout(say.timer);say.timer=setTimeout(()=>{box.hidden=true},8000);box.scrollIntoView({block:'nearest',behavior:'smooth'})}
function setView(view){const owner=view==='owner';$('#owner-screen').hidden=!owner;$('#public-screen').hidden=owner;$$('[data-view]').forEach(b=>{b.classList.toggle('active',b.dataset.view===view);b.setAttribute('aria-pressed',String(b.dataset.view===view))});window.scrollTo({top:0,behavior:'instant'});if(owner)renderOwner();}
$$('[data-view]').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.view)));
$('#reset-demo').addEventListener('click',()=>{if(confirm('Alle demo-invoer op dit apparaat wissen?')){localStorage.removeItem(KEY);initialize();say('Demo teruggezet naar de beginstand.')}});
function appendRows(root,items,callback){if(!items.length){root.innerHTML='<div class="empty">Nog geen aanvragen. Probeer de bezoekerskant.</div>';return}root.innerHTML=items.map(callback).join('')}
function validateEmail(v){return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v).trim())}


const KEY='mcc-factuurflow-v1';
const samples={
 clean:{vendor:'Studio Nova',ref:'SN-0843',date:'2026-10-19',lines:[{label:'Conceptdesign',qty:2,price:450},{label:'Licentiekosten',qty:1,price:180}],vat:.21,total:1306.80},
 wrong:{vendor:'Bureau Atlas',ref:'BA-0051',date:'2026-10-20',lines:[{label:'Hosting service',qty:3,price:75},{label:'Onderhoud',qty:1,price:110}],vat:.21,total:485.00},
 clean2:{vendor:'Werkplaats Bo',ref:'WB-1182',date:'2026-10-18',lines:[{label:'Onderhoud',qty:4,price:130}],vat:.21,total:629.20}
};
const initial=()=>({invoices:[],audit:[]});let db;
const cents=v=>Math.round(v*100);const expected=i=>Math.round(i.lines.reduce((a,l)=>a+l.qty*l.price,0)*(1+i.vat)*100)/100;
const amount=n=>'€ '+Number(n).toFixed(2).replace('.',',');
function initialize(){db=store.load(KEY,initial());renderOwner();$('#invoice-preview').innerHTML='<p class="panel-note">Selecteer een voorbeeld en start de verwerking.</p>'}
$('#process-invoice').onclick=()=>{const sample=samples[$('#invoice-type').value];const record={...JSON.parse(JSON.stringify(sample)),id:uid(),status:cents(expected(sample))===cents(sample.total)?'ter controle':'afwijking',entered:new Date().toISOString()};db.invoices.unshift(record);db.audit.unshift(`${sample.ref}: intake verwerkt · ${record.status}`);store.save(KEY,db);$('#invoice-preview').innerHTML=`<div class="fact-preview"><span class="tag">SIMULATIE / ${escapeHtml(record.ref)}</span><h3>${escapeHtml(record.vendor)}</h3>${record.lines.map(l=>`<p>${escapeHtml(l.label)} · ${l.qty} × ${amount(l.price)}</p>`).join('')}<hr><p><strong>Gelezen totaal: ${amount(record.total)}</strong></p><p>Herberekend totaal: ${amount(expected(record))}</p>${record.status==='afwijking'?'<p class="warnbox">Afwijking gedetecteerd — review vereist.</p>':'<p class="state">Controle geslaagd · klaar voor beoordeling</p>'}</div>`;renderOwner();say(`Factuur ${record.ref} staat in de eigenaarwachtrij. ${record.status==='afwijking'?'Er is een afwijking gedetecteerd.':'Bedragen komen overeen.'}`)};
function renderOwner(){
 $('#invoice-count').textContent=db.invoices.length;
 $('#invoice-anomalies').textContent=db.invoices.filter(i=>i.status==='afwijking').length;
 $('#invoice-approved').textContent=db.invoices.filter(i=>i.status==='goedgekeurd').length;
 $('#invoice-queue').innerHTML=db.invoices.length?db.invoices.map(i=>`<div class="scenario"><div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:10px"><div><strong>${escapeHtml(i.vendor)}</strong><p style="margin:3px 0">${escapeHtml(i.ref)} · ${amount(i.total)}</p><small>Herberekend: ${amount(expected(i))}</small></div><span class="state ${i.status==='afwijking'?'warn':''}">${escapeHtml(i.status)}</span></div>${i.status==='afwijking'?`<label class="field" style="max-width:260px;margin:12px 0">Correct totaal (incl. btw)<input type="number" min="0.01" step="0.01" data-correction="${i.id}" value="${i.total.toFixed(2)}"></label><div class="inline-actions"><button data-fix="${i.id}">Controleer correctie</button></div>`:i.status==='ter controle'?`<div class="inline-actions" style="margin-top:14px"><button data-approve="${i.id}">Goedkeuren (simulatie)</button></div>`:''}</div>`).join(''):'<div class="empty">Nog geen facturen ingediend. Test de intake als bezoeker.</div>';
 $('#invoice-log').innerHTML=db.audit.length?db.audit.map(line=>`<p style="border-bottom:1px solid #ddd;padding:8px 0">${escapeHtml(line)}</p>`).join(''):'<p class="muted">Nog geen gebeurtenissen.</p>';
 $$('[data-fix]').forEach(b=>b.onclick=()=>{const i=db.invoices.find(x=>x.id===b.dataset.fix);const raw=$(`[data-correction="${i.id}"]`).value;const val=Number(raw);if(!Number.isFinite(val)||val<=0){say('Vul een geldig positief bedrag in.',true);return}i.total=Math.round(val*100)/100;if(cents(i.total)===cents(expected(i))){i.status='ter controle';db.audit.unshift(`${i.ref}: gecorrigeerd en opnieuw gevalideerd`);say('Correctie akkoord. Factuur klaar voor beoordeling.')}else{db.audit.unshift(`${i.ref}: afwijking blijft aanwezig`);say(`Afwijking blijft. Verwacht ${amount(expected(i))}.`,true)}store.save(KEY,db);renderOwner()});
 $$('[data-approve]').forEach(b=>b.onclick=()=>{const i=db.invoices.find(x=>x.id===b.dataset.approve);if(cents(i.total)!==cents(expected(i))){say('Goedkeuring geblokkeerd: totaal wijkt af.',true);return}i.status='goedgekeurd';db.audit.unshift(`${i.ref}: door eigenaar goedgekeurd (geen externe boeking)`);store.save(KEY,db);renderOwner();say('Concept goedgekeurd in demo; niets extern geboekt.')});
}
initialize();
