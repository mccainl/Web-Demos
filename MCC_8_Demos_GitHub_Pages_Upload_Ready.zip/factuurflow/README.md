# FACTUUR / FLOW — MCC interactive portfolio concept

This is a fictional, **fully interactive front-end demonstration**. Customer and owner views share browser-local demo data via localStorage. There is no payment processing, no live booking calendar, no external CRM, email, or AI API. Changes are only stored in the same browser; use Reset in the owner dashboard.

## Run
Open `index.html` locally, or serve the folder as a static website. No build dependencies.

## Production upgrade
Add a real database with server-side authorization, privacy/consent, fraud and rate-limit protection, actual integrations, secure payment/booking APIs when appropriate, and automated tests before any real client launch.

Artwork comes from the user's previously generated OpenAI concept images or code-authored UI; not from Higgsfield image generation.

## CTA
Want a custom implementation? DM `CLONE` to `@mccai.nl`.
