# MCC Conceptlab — Eight working interactive demos

An upload-ready GitHub Pages static site for the **MCC-owned GitHub account `mccainl`**. Demo businesses, data, prices and transactions are fictional. Every demo runs purely in the visitor’s browser with localStorage. There are **no genuine payments, emails, CRM integrations, support agents or reservations**. Open the homepage and select a demo, then switch between visitor and owner views.

## Publish (blocked until an MCC-owned repository exists)

1. Create a **new public repository in the MCC account `mccainl`**, suggested name `mcc-conceptlab` (do not use the Care4Gardens client repository or a personal account).
2. Upload the **contents of this folder** to the new repository root, including each demo subdirectory and `.nojekyll`.
3. In Settings → Pages, choose "Deploy from a branch" → `main` / `(root)` and save. Wait for the Pages deployment to finish.
4. Open and independently test the homepage and every project route in desktop and mobile browsers. Confirm the guest→owner state journey on the deployed site.
5. Update the corresponding `mccai.nl` articles and all social captions **with the real URLs only after they work**.
6. Do not publish social posts or Reels before owner approval; all Reels are created and reviewed last.

**Important:** GitHub Pages serves HTML/CSS/JS publicly. Never add credentials or production data. A real multi-user app needs a secure backend; these demos are local-only.
