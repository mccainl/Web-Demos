
const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
const escapeHtml=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const store={load(key,fallback){try{return JSON.parse(localStorage.getItem(key))??fallback}catch{return fallback}},save(key,val){localStorage.setItem(key,JSON.stringify(val))}};
const fmtDate=d=>{try{return new Date(d+'T12:00:00').toLocaleDateString('nl-NL',{day:'numeric',month:'short',year:'numeric'})}catch{return d}};
const nextISO=(days=1)=>{const d=new Date();d.setDate(d.getDate()+days);return d.toISOString().slice(0,10)};
const uid=()=>`${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`;
function say(text,isError=false){const box=$('#feedback');if(!box)return;box.textContent=text;box.classList.toggle('error',isError);box.hidden=false;window.clearTimeout(say.timer);say.timer=setTimeout(()=>{box.hidden=true},8000);box.scrollIntoView({block:'nearest',behavior:'smooth'})}
function setView(view){const owner=view==='owner';$('#owner-screen').hidden=!owner;$('#public-screen').hidden=owner;$$('[data-view]').forEach(b=>{b.classList.toggle('active',b.dataset.view===view);b.setAttribute('aria-pressed',String(b.dataset.view===view))});window.scrollTo({top:0,behavior:'instant'});if(owner)renderOwner();}
$$('[data-view]').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.view)));
$('#reset-demo').addEventListener('click',()=>{if(confirm('Alle demo-invoer op dit apparaat wissen?')){localStorage.removeItem(KEY);initialize();say('Demo teruggezet naar de beginstand.')}});
function appendRows(root,items,callback){if(!items.length){root.innerHTML='<div class="empty">Nog geen aanvragen. Probeer de bezoekerskant.</div>';return}root.innerHTML=items.map(callback).join('')}
function validateEmail(v){return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v).trim())}


const KEY='mcc-rivier-coffee-v1';
const initial=()=>({menu:[
{id:'espresso',name:'Espresso',category:'Koffie',price:3.10,desc:'Klein, krachtig, zorgvuldig gezet.',available:true},
{id:'flat',name:'Flat white',category:'Koffie',price:4.10,desc:'Dubbele espresso met zachte melk.',available:true},
{id:'granola',name:'Huisgemaakte granola',category:'Ontbijt',price:9.80,desc:'Seizoensfruit, yoghurt en geroosterde granen.',available:true},
{id:'toast',name:'Zuurdesemtoast',category:'Ontbijt',price:11.50,desc:'Avocado, kruidenolie en ingelegde groenten.',available:true},
{id:'salad',name:'Salade van het huis',category:'Lunch',price:13.90,desc:'Groene groenten, feta en huisdressing.',available:true},
{id:'tosti',name:'Rivier tosti',category:'Lunch',price:10.20,desc:'Oude kaas, tomatenchutney en salade.',available:true}
],reservations:[]});let db;let category='Alles';
function initialize(){db=store.load(KEY,initial());renderMenu();renderOwner();$('#res-date').min=nextISO(1);$('#res-date').value=nextISO(2)}
function renderMenu(){const items=db.menu.filter(m=>m.available&&(category==='Alles'||m.category===category));$('#menu-items').innerHTML=items.length?items.map((m,i)=>`<article class="tile"><div class="tile-content"><span class="product-tag">${escapeHtml(m.category)} / ${(i+1).toString().padStart(2,'0')}</span><h3>${escapeHtml(m.name)}</h3><p>${escapeHtml(m.desc)}</p><div style="display:flex;justify-content:space-between;align-items:center;margin-top:22px"><strong>€ ${m.price.toFixed(2).replace('.',',')}</strong><span class="muted">Vers bereid</span></div></div></article>`).join(''):'<div class="empty">Momenteel geen gerechten in deze categorie beschikbaar.</div>'}
$$('[data-menu]').forEach(b=>b.onclick=()=>{category=b.dataset.menu;$$('[data-menu]').forEach(t=>t.classList.toggle('selected',t===b));renderMenu()});
$('#reserve-form').onsubmit=e=>{e.preventDefault();const name=$('#res-name').value.trim(),email=$('#res-email').value.trim(),date=$('#res-date').value,time=$('#res-time').value,guests=Number($('#res-guests').value);if(!name||!validateEmail(email)||date<nextISO(1)){say('Kies een toekomstige datum en vul je gegevens goed in.',true);return}const spots=db.reservations.filter(r=>r.date===date&&r.time===time&&r.status!=='geannuleerd').length;if(spots>=4){say('Dit tijdstip is vol in de simulatie. Kies een ander.',true);return}db.reservations.unshift({id:uid(),name,email,date,time,guests,status:'nieuw'});store.save(KEY,db);renderOwner();say(`Conceptreservering ontvangen voor ${guests} gast(en) op ${fmtDate(date)} om ${time}. Bekijk deze in de eigenaarweergave.`);e.target.reset();$('#res-date').value=nextISO(2)};
function renderOwner(){
 $('#res-count').textContent=db.reservations.filter(r=>r.status!=='geannuleerd').length;
 $('#res-pending').textContent=db.reservations.filter(r=>r.status==='nieuw').length;
 $('#live-menu').textContent=db.menu.filter(m=>m.available).length;
 $('#reservation-list').innerHTML=db.reservations.length?db.reservations.map(r=>`<div class="scenario"><strong>${escapeHtml(r.name)}</strong> <span class="state ${r.status==='geannuleerd'?'off':r.status==='nieuw'?'warn':''}">${escapeHtml(r.status)}</span><p>${fmtDate(r.date)} · ${escapeHtml(r.time)} · ${r.guests} gasten</p><div class="inline-actions">${r.status==='nieuw'?`<button data-res="${r.id}" data-action="bevestigd">Bevestigen</button>`:''}${r.status!=='geannuleerd'?`<button data-res="${r.id}" data-action="geannuleerd">Annuleren</button>`:''}</div></div>`).join(''):'<div class="empty">Nog geen reserveringen. Probeer het formulier als bezoeker.</div>';
 $('#owner-menu').innerHTML=db.menu.map(m=>`<div class="scenario" style="display:flex;align-items:center;justify-content:space-between;gap:10px"><div><strong>${escapeHtml(m.name)}</strong><p style="margin:0">€ ${m.price.toFixed(2).replace('.',',')} · ${m.available?'Zichtbaar':'Verborgen'}</p></div><button class="outline" data-item="${m.id}">${m.available?'Verberg':'Toon'}</button></div>`).join('');
 $$('[data-res]').forEach(b=>b.onclick=()=>{db.reservations.find(r=>r.id===b.dataset.res).status=b.dataset.action;store.save(KEY,db);renderOwner();say('Reserveringsstatus bijgewerkt in deze demo.')});
 $$('[data-item]').forEach(b=>b.onclick=()=>{const item=db.menu.find(x=>x.id===b.dataset.item);item.available=!item.available;store.save(KEY,db);renderMenu();renderOwner();say(`Menukaart aangepast: ${item.name}.`)})
}
initialize();
