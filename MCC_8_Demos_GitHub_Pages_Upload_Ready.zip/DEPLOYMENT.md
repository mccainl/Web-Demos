# MCC interactive demo gallery (staged — NOT YET DEPLOYED)

This root folder is ready to be copied to the root of a **new, separate** GitHub Pages repository owned by `mccainl` (not the Care4Gardens client repo).

- `index.html` lists eight distinct demos. Each project lives at `./<slug>/` with static HTML/CSS/JS and local OpenAI-created concept images as appropriate.
- All enquiry/bookings are fictional browser-only simulations, not actual client services. Browser localStorage data cannot sync across devices.
- Post the matching blog articles only after the demo URLs have been verified.
- No Reels or social publishing until the owner individually approves them.

## Publication checklist

1. Create a new public repository in MCC's `mccainl` account, e.g. `mcc-showcase`. This repository does **not** exist in the connected account yet.
2. Copy the gallery and each site directory, including all `assets/*.webp`.
3. Enable GitHub Pages on the `main` branch, root folder.
4. Open the public gallery URL and **each** `/<slug>/` link in a real browser.
5. Run booking and owner flows on hosted URLs; confirm no live data is collected.
6. Add the exact verified URL to the corresponding MCC blog post, then publish the posts on mccai.nl and cross-link.
7. After supporting carousel review, finally produce the eight Reels separately.
