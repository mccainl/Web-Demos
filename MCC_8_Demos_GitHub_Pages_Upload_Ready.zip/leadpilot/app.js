/* MCC LeadPilot — browser-only, sample-data concept demo. No external CRM/email calls. */
(() => {
  'use strict';
  const KEY = 'mcc-leadpilot-sample-2026-v1';
  const STAGES = ['Nieuw', 'In gesprek', 'Voorstel', 'Gewonnen'];
  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => Array.from(document.querySelectorAll(selector));
  const now = () => new Date().toISOString();
  const day = (offset) => { const d = new Date(); d.setDate(d.getDate() + offset); return d.toISOString(); };
  const makeId = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
  const esc = (text) => String(text ?? '').replace(/[&<>"']/g, (c) => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' })[c]);
  const getDate = (iso) => new Date(iso).toLocaleDateString('nl-NL', {day:'numeric',month:'short'});
  const getDateTime = (iso) => new Date(iso).toLocaleString('nl-NL', {day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'});
  const initial = () => ({
    leads: [
      {id:'sample-001',company:'Studio Hout',email:'hallo@studiohout.example',service:'Website',budget:'€ 2.500–€ 5.000',timeline:'Binnen 1 maand',description:'We zoeken een nieuwe website waarin onze projecten en diensten op een rustige manier samenkomen.',stage:'Nieuw',notes:'',createdAt:day(-1)},
      {id:'sample-002',company:'Atelier Verde',email:'team@atelierverde.example',service:'Webapp',budget:'€ 5.000+',timeline:'Later dit jaar',description:'We willen aanvragen en lopende projecten centraal beheren, zodat iedereen weet wat de volgende stap is.',stage:'In gesprek',notes:'De wensen voor het klantportaal bespreken.',createdAt:day(-3)},
      {id:'sample-003',company:'Noord & Co.',email:'info@noordenco.example',service:'Automatisering',budget:'€ 2.500–€ 5.000',timeline:'Binnen 2 weken',description:'Factuurgegevens overtypen neemt te veel tijd in beslag; kan het automatisch gecontroleerd worden?',stage:'Voorstel',notes:'Eerste scope is uitgewerkt; wacht op feedback.',createdAt:day(-4)},
      {id:'sample-004',company:'Bloom Collective',email:'studio@bloomcollective.example',service:'AI assistent',budget:'Nog te bepalen',timeline:'Geen haast',description:'Klanten stellen vaak dezelfde vragen en we willen sneller reageren op nieuwe aanvragen.',stage:'Nieuw',notes:'',createdAt:day(-2)},
      {id:'sample-005',company:'Kade Studio',email:'hello@kadestudio.example',service:'Website',budget:'€ 2.500–€ 5.000',timeline:'Geen haast',description:'We willen onze diensten duidelijker uitleggen en aanvragen uit het contactformulier verzamelen.',stage:'Gewonnen',notes:'Demo-status: project wordt opgepakt.',createdAt:day(-11)}
    ],
    tasks: [
      {id:'task-001',title:'Reactie op Studio Hout voorbereiden',leadId:'sample-001',done:false,createdAt:day(-1)},
      {id:'task-002',title:'Projectgesprek met Atelier Verde plannen',leadId:'sample-002',done:false,createdAt:day(-2)},
      {id:'task-003',title:'Voorstel Noord & Co. controleren',leadId:'sample-003',done:false,createdAt:day(-1)},
      {id:'task-004',title:'Vragen voor Bloom Collective verzamelen',leadId:'sample-004',done:false,createdAt:day(0)}
    ],
    activity: [{id:'evt-001',text:'Demogegevens voor de ondernemersomgeving geladen',createdAt:day(0)}]
  });
  let model;
  try { model = JSON.parse(localStorage.getItem(KEY)) || initial(); } catch { model = initial(); }
  function save(){ try { localStorage.setItem(KEY,JSON.stringify(model)); } catch { /* Browser may block storage; demo remains in memory. */ } }
  function announce(text){ $('#announcer').textContent = text; }
  function log(text){ model.activity.unshift({id:makeId(),text,createdAt:now()}); model.activity=model.activity.slice(0,35); }
  function setView(view){
    for (const name of ['customer','owner']){
      const on = view === name;
      $(`#${name}-view`).hidden = !on;
      $(`#tab-${name}`).classList.toggle('active',on);
      $(`#tab-${name}`).setAttribute('aria-selected',String(on));
    }
    if (view === 'owner') renderAll();
    scrollTo({top:0,behavior:'smooth'});
    announce(view === 'owner' ? 'Ondernemersdashboard geopend' : 'Klantformulier geopend');
  }
  for (const button of $$('.switch-button')) button.addEventListener('click', () => setView(button.dataset.view));
  const form = $('#enquiry-form');
  form.addEventListener('submit',(e)=>{
    e.preventDefault();
    const company = $('#company').value.trim();
    const email = $('#email').value.trim();
    const description = $('#description').value.trim();
    const bad = (message) => { $('#form-error').textContent = message; $('#form-error').hidden = false; announce(message); };
    if(company.length < 2 || company.length > 65) return bad('Vul een naam of bedrijfsnaam in van ten minste twee tekens.');
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 150) return bad('Vul een geldig test-e-mailadres in.');
    if(description.length < 12 || description.length > 650) return bad('Vertel iets meer over je project: minimaal twaalf tekens.');
    const service = $('input[name="service"]:checked')?.value || 'Website';
    const item = {id:makeId(),company,email,service,budget:$('#budget').value,timeline:$('#timeline').value,description,stage:'Nieuw',notes:'',createdAt:now()};
    model.leads.unshift(item);
    const task = {id:makeId(),title:`Neem contact op met ${company}`,leadId:item.id,done:false,createdAt:now()};
    model.tasks.unshift(task);
    log(`Nieuwe conceptaanvraag ontvangen van ${company} (${service})`);
    log(`Opvolgtaak voor ${company} aangemaakt`);
    save();
    $('#form-error').hidden = true;
    form.reset();
    $('#confirmation').hidden = false;
    $('#confirmation').scrollIntoView({behavior:'smooth',block:'center'});
    announce(`Aanvraag voor ${company} lokaal opgeslagen. Je kunt hem nu in het ondernemersdashboard bekijken.`);
  });
  $('#open-owner').addEventListener('click',()=>{setView('owner');setPage('pipeline')});
  $('#another-enquiry').addEventListener('click',()=>{$('#confirmation').hidden=true;$('#brief').scrollIntoView({behavior:'smooth'})});
  function setPage(page){
    for(const section of $$('[data-owner-page]')) section.hidden = section.dataset.ownerPage !== page;
    for(const button of $$('.nav-link')) button.classList.toggle('active',button.dataset.page===page);
    $('#owner-page-title').textContent = ({overview:'Overzicht',pipeline:'Pijplijn',tasks:'Taken',activity:'Activiteit'})[page] || page;
    renderAll();
  }
  for(const b of $$('.nav-link,.go-page')) b.addEventListener('click',()=>setPage(b.dataset.page));
  const leadTemplate = (lead) => `<button class="lead-row" data-lead-id="${esc(lead.id)}"><span><strong>${esc(lead.company)}</strong><small>${esc(lead.service)} · ${getDate(lead.createdAt)}</small></span><span class="stage stage-${esc(lead.stage.toLowerCase().replace(' ','-'))}">${esc(lead.stage)}</span></button>`;
  const taskTemplate = (task) => {const company=model.leads.find(l=>l.id===task.leadId)?.company || 'Algemeen';return `<div class="task-item"><input type="checkbox" id="task-${esc(task.id)}" data-task-id="${esc(task.id)}" ${task.done?'checked':''}><label for="task-${esc(task.id)}">${esc(task.title)}<small>${esc(company)} · demo</small></label></div>`};
  function renderOverview(){
    $('#stat-open').textContent=String(model.leads.filter(l=>!['Gewonnen'].includes(l.stage)).length).padStart(2,'0');
    $('#stat-proposals').textContent=String(model.leads.filter(l=>l.stage==='Voorstel').length).padStart(2,'0');
    $('#stat-tasks').textContent=String(model.tasks.filter(t=>!t.done).length).padStart(2,'0');
    $('#nav-new-count').textContent=String(model.leads.filter(l=>l.stage==='Nieuw').length).padStart(2,'0');
    $('#nav-task-count').textContent=String(model.tasks.filter(t=>!t.done).length).padStart(2,'0');
    $('#recent-leads').innerHTML=model.leads.slice().sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)).slice(0,5).map(leadTemplate).join('') || '<p>Nog geen aanvragen.</p>';
    $('#overview-tasks').innerHTML=model.tasks.filter(t=>!t.done).slice(0,4).map(taskTemplate).join('') || '<p>Alle taken afgerond.</p>';
  }
  function renderPipeline(){
    const q=$('#lead-search').value.trim().toLocaleLowerCase('nl-NL');
    const items=model.leads.filter(l=>`${l.company} ${l.email} ${l.service}`.toLowerCase().includes(q));
    $('#pipeline-columns').innerHTML=STAGES.map(stage=>{
      const leads=items.filter(l=>l.stage===stage);
      return `<div class="pipeline-column"><div class="col-name">${esc(stage)}<span class="col-counter">${String(leads.length).padStart(2,'0')}</span></div><div class="subline"></div>${leads.length?leads.map(l=>`<button type="button" class="pipeline-card" data-lead-id="${esc(l.id)}"><span class="service">${esc(l.service.toUpperCase())}</span><strong>${esc(l.company)}</strong><small>${getDate(l.createdAt)} · ${esc(l.budget)}</small></button>`).join(''):'<p class="col-empty">Nog geen aanvragen</p>'}</div>`
    }).join('');
  }
  function renderTasks(){ $('#all-tasks').innerHTML=model.tasks.slice().sort((a,b)=>Number(a.done)-Number(b.done)).map(taskTemplate).join('')||'<p>Nog geen taken.</p>'; }
  function renderActivity(){ $('#activity-list').innerHTML=model.activity.map(e=>`<div class="activity-entry"><span class="activity-dot"></span><div><strong>${esc(e.text)}</strong><small>Opgeslagen in deze browser</small></div><time datetime="${esc(e.createdAt)}">${getDateTime(e.createdAt)}</time></div>`).join(''); }
  function renderAll(){renderOverview();renderPipeline();renderTasks();renderActivity();}
  $('#lead-search').addEventListener('input',renderPipeline);
  document.addEventListener('click',(e)=>{const b=e.target.closest('[data-lead-id]');if(b) openDetail(b.dataset.leadId);});
  document.addEventListener('change',(e)=>{if(!e.target.matches('[data-task-id]'))return;const item=model.tasks.find(t=>t.id===e.target.dataset.taskId);if(!item)return;item.done=e.target.checked;log(`${item.done?'Taak afgerond':'Taak heropend'}: ${item.title}`);save();renderAll();announce(item.done?'Taak afgerond':'Taak heropend');});
  $('#add-task-form').addEventListener('submit',(e)=>{e.preventDefault();const text=$('#new-task').value.trim();if(text.length<3)return;model.tasks.unshift({id:makeId(),title:text,leadId:null,done:false,createdAt:now()});log(`Nieuwe taak: ${text}`);$('#new-task').value='';save();renderAll();announce('Nieuwe opvolgtaak toegevoegd')});
  $('#reset-demo').addEventListener('click',()=>{if(!confirm('Wil je de lokale demo herstellen? Je testaanvragen, notities en aangepaste taken verdwijnen.'))return;model=initial();save();$('#confirmation').hidden=true;$('#lead-search').value='';hideDetail();setPage('overview');announce('Oorspronkelijke demogegevens hersteld')});
  $('#new-sample').addEventListener('click',()=>{const name=`Proefaanvraag ${model.leads.length+1}`;const lead={id:makeId(),company:name,email:'demo@voorbeeld.example',service:'Website',budget:'Nog te bepalen',timeline:'Binnen 1 maand',description:'We onderzoeken een interactieve website met een helder contactmoment.',stage:'Nieuw',notes:'',createdAt:now()};model.leads.unshift(lead);log(`Nieuwe voorbeeldlead toegevoegd: ${name}`);save();renderAll();openDetail(lead.id);announce('Voorbeeldlead toegevoegd')});
  let detailId=null;
  function openDetail(id){
    const l=model.leads.find(x=>x.id===id);if(!l)return;detailId=id;
    $('#detail-title').textContent=l.company;
    $('#detail-body').innerHTML=`
       <div class="detail-group"><div class="detail-label">Dienst</div><div class="detail-value">${esc(l.service)}</div></div>
       <div class="detail-group"><div class="detail-label">Contact · fictieve of testgegevens</div><div class="detail-value">${esc(l.email)}</div></div>
       <div class="detail-group"><div class="detail-label">Aanvraag</div><div class="detail-value">${esc(l.description)}</div></div>
       <div class="detail-group"><div class="detail-label">Start & budget</div><div class="detail-value">${esc(l.timeline)} · ${esc(l.budget)}</div></div>
       <div class="detail-group"><div class="detail-label"><label for="detail-stage">Fase in pijplijn</label></div><select id="detail-stage">${STAGES.map(s=>`<option value="${esc(s)}" ${l.stage===s?'selected':''}>${esc(s)}</option>`).join('')}</select></div>
       <div class="detail-group"><div class="detail-label"><label for="detail-notes">Interne notities (lokaal)</label></div><textarea id="detail-notes" placeholder="Noteer de volgende stap">${esc(l.notes)}</textarea></div>
       <div class="detail-actions"><button type="button" id="save-detail">Sla wijzigingen op ↗</button><button type="button" id="detail-create-task" class="muted-btn">+ Plan opvolging</button></div>
    `;
    $('#detail-backdrop').hidden=false;
    document.body.style.overflow='hidden';
    $('#lead-detail').focus();
    $('#save-detail').addEventListener('click',()=>{const before=l.stage;l.stage=$('#detail-stage').value;l.notes=$('#detail-notes').value.slice(0,1200);log(`Aanvraag ${l.company} opgeslagen${before!==l.stage?` (${before} → ${l.stage})`:''}`);save();renderAll();hideDetail();announce(`Aanvraag van ${l.company} bijgewerkt`)});
    $('#detail-create-task').addEventListener('click',()=>{const title=`Volg ${l.company} op`;model.tasks.unshift({id:makeId(),title,leadId:l.id,done:false,createdAt:now()});log(`Opvolgtaak voor ${l.company} gepland`);save();renderAll();hideDetail();setPage('tasks');announce('Opvolgtaak toegevoegd')});
  }
  function hideDetail(){ $('#detail-backdrop').hidden=true;document.body.style.overflow='';detailId=null; }
  $('#close-detail').addEventListener('click',hideDetail);
  $('#detail-backdrop').addEventListener('click',(e)=>{if(e.target===e.currentTarget)hideDetail()});
  window.addEventListener('keydown',(e)=>{if(e.key==='Escape')hideDetail()});
  $('#today-label').textContent=new Date().toLocaleDateString('nl-NL',{weekday:'long',day:'numeric',month:'long'});
  save();
  renderAll();
})();
