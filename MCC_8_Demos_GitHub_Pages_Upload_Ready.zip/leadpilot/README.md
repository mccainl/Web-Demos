# LeadPilot — MCC AI Automation conceptdemo

**Status:** browser-tested local concept; **not** published to GitHub Pages and **not** a live CRM. This website contains simulated fictional records. Do not collect real customer information with this prototype.

## What this demonstrates

A small business can turn a customer enquiry into an organized follow-up rather than leave it in a crowded email inbox. Two views are available from the top navigation:

1. **For the customer:** choose website/webapp/automation/AI, supply a sample project brief and optional budget/timeline, submit the sample enquiry, see an honest in-browser confirmation.
2. **For the owner:** see the received sample lead in the overview and pipeline, select and move it between stages, save a note, create and tick off follow-up tasks, inspect activity and reset the demo.

The demo uses localStorage in the visitor's own browser; **no server, email or CRM integration is live**. All sample company names, budgets and results are fictional. Enter test data only. A real implementation needs server-side validation, privacy controls, auth, protected client data, a CRM connector and deliverability/monitoring.

## Try locally

Serve this directory through a local web server, e.g.:

```sh
python3 -m http.server 8080
# Open http://localhost:8080
```

The project has no build step or external runtime dependencies. The Google Fonts import is optional and is replaced by system font fallbacks if unavailable.

## QA

- Responsive screenshots: `previews/`
- Browser tests: `tests/test_leadpilot.py` — used to check customer submission → pipeline → stage and notes → task → persistence, mobile overflow and reset.
- To run the test outside a restricted browser sandbox, use Playwright against a local HTTP server, or use the provided inline-content fallback in the script.

## Publishing pipeline

This is the fourth of eight approved MCC campaign examples. The matching blog drafts and two carousels are included. **Do not schedule/publish until** (1) there is a verified live demo on `mccainl` GitHub Pages, (2) a matching live MCC blog post, and (3) owner approval of the individual posts and, later, the Reel. The Reel comes last.

## Production upgrade

Swap localStorage for an authenticated server-side application, validated enquiry API, role permissions, encrypted data store, safe contact delivery, audit trail, rate limiting, GDPR procedures and CRM integration. Never represent this demo as a production system or its example figures as verified business performance.
