/* MAREA STAY — interactive sample hotel experience by MCC.
   Intentional local-only demo: no backend, payment, email, or real inventory. */
(() => {
  'use strict';
  const KEY = 'mcc-marea-stay-bookings-v1';
  const rooms = [
    { id: 'suite', name: 'De Dune Suite', price: 195, capacity: 2, image: 'assets/suite.webp', size: '32 m²' },
    { id: 'terrace', name: 'Casa do Mar', price: 265, capacity: 3, image: 'assets/terrace.webp', size: '42 m²' },
    { id: 'pool', name: 'The Courtyard', price: 320, capacity: 4, image: 'assets/pool.webp', size: '64 m²' },
  ];
  const $ = selector => document.querySelector(selector);
  const $$ = selector => [...document.querySelectorAll(selector)];
  const euro = n => new Intl.NumberFormat('nl-NL', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(n);
  const humanDate = value => new Intl.DateTimeFormat('nl-NL', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' }).format(new Date(value + 'T12:00:00Z'));
  const dayMs = 86400000;
  const isoDate = date => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  const offsetDate = n => { const d = new Date(); d.setHours(12, 0, 0, 0); d.setDate(d.getDate() + n); return isoDate(d); };
  const addDays = (iso, n) => { const d = new Date(iso + 'T12:00:00'); d.setDate(d.getDate() + n); return isoDate(d); };
  const nights = (from, to) => Math.round((Date.parse(to + 'T12:00:00Z') - Date.parse(from + 'T12:00:00Z')) / dayMs);
  const safeStorage = {
    get: () => { try { return localStorage.getItem(KEY); } catch { return null; } },
    set: value => { try { localStorage.setItem(KEY, JSON.stringify(value)); return true; } catch { return false; } },
  };
  const starter = () => [
    { id: 'MR-SAMPLE-01', name: 'Voorbeeldgast A', email: 'sample-a@example.com', roomId: 'suite', checkin: offsetDate(14), checkout: offsetDate(17), guests: 2, total: 585, status: 'confirmed', sample: true },
    { id: 'MR-SAMPLE-02', name: 'Voorbeeldgast B', email: 'sample-b@example.com', roomId: 'terrace', checkin: offsetDate(21), checkout: offsetDate(25), guests: 3, total: 1060, status: 'confirmed', sample: true },
  ];
  let bookings = (() => {
    const stored = safeStorage.get();
    if (stored !== null) { try { const value = JSON.parse(stored); if (Array.isArray(value)) return value; } catch {} }
    const seeded = starter(); safeStorage.set(seeded); return seeded;
  })();
  const state = { checkin: offsetDate(1), checkout: offsetDate(4), guests: 2, selectedRoom: null };
  let lastFocus = null;
  const persist = () => safeStorage.set(bookings);
  const validDates = (from, to) => from >= isoDate(new Date()) && nights(from, to) > 0 && nights(from, to) <= 30;
  const roomById = id => rooms.find(room => room.id === id);
  const available = room => room.capacity >= state.guests && !bookings.some(b => b.roomId === room.id && b.status !== 'cancelled' && state.checkin < b.checkout && state.checkout > b.checkin);
  function setError(message) {
    const node = $('#drawer-error'); node.textContent = message || ''; node.hidden = !message;
  }
  function syncTopDates() {
    $('#checkin').value = state.checkin; $('#checkout').value = state.checkout; $('#guests').value = String(state.guests);
    $('#drawer-checkin').value = state.checkin; $('#drawer-checkout').value = state.checkout; $('#drawer-guests').value = String(state.guests);
    for (const id of ['checkin', 'checkout', 'drawer-checkin', 'drawer-checkout']) $( `#${id}` ).min = id.includes('checkout') ? addDays(state.checkin, 1) : isoDate(new Date());
  }
  function updateFrom(which) {
    state.checkin = $(which === 'drawer' ? '#drawer-checkin' : '#checkin').value;
    state.checkout = $(which === 'drawer' ? '#drawer-checkout' : '#checkout').value;
    state.guests = Number($(which === 'drawer' ? '#drawer-guests' : '#guests').value);
    if (state.checkout <= state.checkin) state.checkout = addDays(state.checkin, 2);
    syncTopDates(); renderRoomOptions();
  }
  function renderRoomOptions() {
    const container = $('#drawer-room-options'); container.replaceChildren();
    const dateOk = validDates(state.checkin, state.checkout);
    if (state.selectedRoom && (!dateOk || !available(roomById(state.selectedRoom)))) state.selectedRoom = null;
    const anyAvailable = rooms.some(room => dateOk && available(room));
    rooms.forEach(room => {
      const possible = dateOk && available(room);
      const button = document.createElement('button'); button.type = 'button'; button.className = 'room-option';
      button.setAttribute('role', 'radio'); button.setAttribute('aria-checked', String(state.selectedRoom === room.id)); button.disabled = !possible;
      const photo = document.createElement('img'); photo.src = room.image; photo.alt = '';
      const copy = document.createElement('div'); const strong = document.createElement('strong'); strong.textContent = room.name;
      const small = document.createElement('small'); small.textContent = possible ? `${room.size} · voor ${room.capacity} gasten` : (room.capacity < state.guests ? 'Te klein voor dit gezelschap' : 'Niet beschikbaar voor deze data');
      copy.append(strong, small);
      const rate = document.createElement('span'); rate.className = 'rate'; rate.textContent = euro(room.price) + ' / nacht';
      button.append(photo, copy, rate);
      button.addEventListener('click', () => { state.selectedRoom = room.id; setError(''); renderRoomOptions(); });
      container.append(button);
    });
    if (!dateOk) setError('Kies een aankomstdatum vanaf vandaag en minimaal één, maximaal dertig nachten.');
    else if (!anyAvailable) setError('Voor deze data zijn geen suites beschikbaar. Probeer andere data of minder gasten.');
    else setError('');
    const selected = roomById(state.selectedRoom);
    $('#summary-room').textContent = selected ? `${selected.name} · ${nights(state.checkin, state.checkout)} nachten` : 'Selecteer een suite';
    $('#summary-total').textContent = selected ? euro(selected.price * nights(state.checkin, state.checkout)) : '€ 0';
  }
  function lockPage(locked) { document.body.classList.toggle('lock', locked); }
  function openBooking(id = null) {
    lastFocus = document.activeElement; $('#admin-overlay').hidden = true; $('#booking-overlay').hidden = false;
    $('#booking-form').hidden = false; $('#confirmation').hidden = true; state.selectedRoom = id;
    $('#drawer-progress').textContent = '01 / KIES JE KAMER';
    syncTopDates(); renderRoomOptions(); lockPage(true); $('.booking-drawer').focus();
  }
  function closeBooking() { $('#booking-overlay').hidden = true; lockPage(false); if (lastFocus && typeof lastFocus.focus === 'function') lastFocus.focus(); }
  function openAdmin() { lastFocus = document.activeElement; $('#booking-overlay').hidden = true; $('#admin-overlay').hidden = false; lockPage(true); renderAdmin(); $('.admin-panel').focus(); }
  function closeAdmin() { $('#admin-overlay').hidden = true; lockPage(false); if (lastFocus && typeof lastFocus.focus === 'function') lastFocus.focus(); }
  function confirmBooking(event) {
    event.preventDefault();
    const selected = roomById(state.selectedRoom);
    if (!validDates(state.checkin, state.checkout)) return setError('Kies geldige verblijfdata.');
    if (!selected) return setError('Selecteer eerst een beschikbare suite.');
    if (!available(selected)) return setError('Die suite is niet meer beschikbaar voor jouw data. Kies een andere suite of andere data.');
    const name = $('#guest-name').value.trim(); const email = $('#guest-email').value.trim();
    if (name.length < 2 || !$('#guest-email').checkValidity()) return setError('Voer een voorbeeldnaam en een geldig e-mailadres in. Gebruik bij voorkeur fictieve gegevens.');
    const id = `MR-${new Date().getFullYear()}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
    bookings.unshift({ id, name, email, roomId: selected.id, checkin: state.checkin, checkout: state.checkout, guests: state.guests, total: selected.price * nights(state.checkin, state.checkout), status: 'confirmed', sample: false });
    persist(); $('#booking-form').hidden = true; $('#confirmation').hidden = false; $('#confirmation-id').textContent = id; $('#drawer-progress').textContent = '02 / BEVESTIGD'; setError('');
    $('#booking-form').reset();
  }
  function makeCell(text, sub = null) {
    const cell = document.createElement('td');
    if (sub) { const primary = document.createElement('strong'); primary.textContent = text; const secondary = document.createElement('small'); secondary.textContent = sub; cell.append(primary, secondary); }
    else cell.textContent = text;
    return cell;
  }
  function renderAdmin() {
    const active = bookings.filter(b => b.status !== 'cancelled');
    $('#metric-bookings').textContent = String(active.length);
    $('#metric-revenue').textContent = euro(active.reduce((sum, b) => sum + b.total, 0));
    $('#metric-guests').textContent = String(active.reduce((sum, b) => sum + b.guests, 0));
    const filter = $('#status-filter').value; const rows = $('#booking-rows'); rows.replaceChildren();
    const visible = bookings.filter(b => filter === 'all' || b.status === filter);
    $('#empty-bookings').hidden = visible.length > 0;
    const names = { confirmed: 'Bevestigd', 'checked-in': 'Ingecheckt', cancelled: 'Geannuleerd' };
    visible.forEach(b => {
      const tr = document.createElement('tr');
      tr.append(makeCell(b.name, (b.sample ? 'Voorbeelddata · ' : 'Eigen test · ') + b.id));
      tr.append(makeCell(roomById(b.roomId)?.name || b.roomId, `${b.guests} ${b.guests === 1 ? 'gast' : 'gasten'}`));
      tr.append(makeCell(humanDate(b.checkin), 't/m ' + humanDate(b.checkout)));
      tr.append(makeCell(euro(b.total)));
      const statusTd = document.createElement('td'); const status = document.createElement('span'); status.className = 'status-chip ' + b.status; status.textContent = names[b.status] || b.status; statusTd.append(status); tr.append(statusTd);
      const actions = document.createElement('td');
      const checkIn = document.createElement('button'); checkIn.type = 'button'; checkIn.textContent = 'Check-in'; checkIn.disabled = b.status !== 'confirmed';
      checkIn.addEventListener('click', () => { b.status = 'checked-in'; persist(); renderAdmin(); });
      const cancel = document.createElement('button'); cancel.type = 'button'; cancel.textContent = 'Annuleer'; cancel.disabled = b.status === 'cancelled';
      cancel.addEventListener('click', () => { b.status = 'cancelled'; persist(); renderAdmin(); });
      actions.append(checkIn, cancel); tr.append(actions); rows.append(tr);
    });
  }
  function resetDemo() {
    if (!window.confirm('Alle lokale testboekingen wissen en de twee voorbeeldboekingen herstellen?')) return;
    bookings = starter(); persist(); $('#status-filter').value = 'all'; state.selectedRoom = null; renderAdmin();
  }
  // Initialize date selection.
  syncTopDates();
  $('#availability-form').addEventListener('submit', event => { event.preventDefault(); updateFrom('top'); openBooking(); });
  ['checkin', 'checkout', 'guests'].forEach(id => $('#' + id).addEventListener('change', () => updateFrom('top')));
  ['drawer-checkin', 'drawer-checkout', 'drawer-guests'].forEach(id => $('#' + id).addEventListener('change', () => updateFrom('drawer')));
  $$('[data-open-booking]').forEach(btn => btn.addEventListener('click', () => openBooking()));
  $$('[data-book-room]').forEach(btn => btn.addEventListener('click', () => { if (state.guests > roomById(btn.dataset.bookRoom).capacity) state.guests = roomById(btn.dataset.bookRoom).capacity; openBooking(btn.dataset.bookRoom); }));
  $$('[data-close-booking]').forEach(btn => btn.addEventListener('click', closeBooking));
  $$('[data-close-admin]').forEach(btn => btn.addEventListener('click', closeAdmin));
  $('#booking-form').addEventListener('submit', confirmBooking);
  $('#open-admin').addEventListener('click', openAdmin);
  $('#admin-mobile').addEventListener('click', openAdmin);
  $('#confirmation-open-admin').addEventListener('click', openAdmin);
  $('#status-filter').addEventListener('change', renderAdmin);
  $('#reset-demo').addEventListener('click', resetDemo);
  $('#menu-toggle').addEventListener('click', () => { const open = $('#mobile-menu').hidden; $('#mobile-menu').hidden = !open; $('#menu-toggle').setAttribute('aria-expanded', String(open)); });
  $$('#mobile-menu a, #mobile-menu button').forEach(el => el.addEventListener('click', () => { $('#mobile-menu').hidden = true; $('#menu-toggle').setAttribute('aria-expanded', 'false'); }));
  window.addEventListener('keydown', event => { if (event.key === 'Escape') { if (!$('#admin-overlay').hidden) closeAdmin(); else if (!$('#booking-overlay').hidden) closeBooking(); else if (!$('#mobile-menu').hidden) { $('#mobile-menu').hidden = true; $('#menu-toggle').setAttribute('aria-expanded', 'false'); } } });
  window.addEventListener('scroll', () => $('#site-header').classList.toggle('scrolled', window.scrollY > 35), { passive: true });
})();
