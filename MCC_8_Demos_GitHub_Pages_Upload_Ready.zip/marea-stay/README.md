# Marea Stay — MCC Interactive Portfolio Concept

Marea Stay is a **fictional** boutique-hotel website created to demonstrate both a front-end guest booking journey and a lightweight owner dashboard. It is *not* a real hotel booking service.

## Features

- Editorial responsive website and three distinct suites
- Stay-date and guest-count selection, availability calculation, price summary
- Local browser-only reservation confirmation (no payment or email)
- Owner dashboard with bookings, KPIs, check-in, cancellation and reset
- No external API, keys, server or data collection; sample data stored in local browser storage
- Mobile navigation, keyboard-focus styling and reduced-motion support

## How to run

Open `index.html` in a browser or serve this folder with any static web server. The code has no build step. For multi-device synchronization and real reservations, a secure backend must be built separately.

## Demo disclaimer

All guest bookings are simulated locally. `localStorage` may retain entries in the user's browser; use the **Reset demo** action to clear them. Use fictitious names and email addresses. No payments or real availability.

## Image assets

The four photographic-style image assets in `assets/*.webp` were generated using **OpenAI's image generation** for this fictional portfolio concept, then cropped/optimized for site use. Do not present this concept as a real property or client project.

## MCC lifecycle

The matching article is currently a draft in `../blog-drafts/2026-10-26-marea-stay-nl.md`. Add verified live demo and blog URLs before creating the Reel or publishing social posts.
