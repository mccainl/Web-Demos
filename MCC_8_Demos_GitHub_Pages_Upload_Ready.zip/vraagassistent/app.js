
const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
const escapeHtml=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const store={load(key,fallback){try{return JSON.parse(localStorage.getItem(key))??fallback}catch{return fallback}},save(key,val){localStorage.setItem(key,JSON.stringify(val))}};
const fmtDate=d=>{try{return new Date(d+'T12:00:00').toLocaleDateString('nl-NL',{day:'numeric',month:'short',year:'numeric'})}catch{return d}};
const nextISO=(days=1)=>{const d=new Date();d.setDate(d.getDate()+days);return d.toISOString().slice(0,10)};
const uid=()=>`${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`;
function say(text,isError=false){const box=$('#feedback');if(!box)return;box.textContent=text;box.classList.toggle('error',isError);box.hidden=false;window.clearTimeout(say.timer);say.timer=setTimeout(()=>{box.hidden=true},8000);box.scrollIntoView({block:'nearest',behavior:'smooth'})}
function setView(view){const owner=view==='owner';$('#owner-screen').hidden=!owner;$('#public-screen').hidden=owner;$$('[data-view]').forEach(b=>{b.classList.toggle('active',b.dataset.view===view);b.setAttribute('aria-pressed',String(b.dataset.view===view))});window.scrollTo({top:0,behavior:'instant'});if(owner)renderOwner();}
$$('[data-view]').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.view)));
$('#reset-demo').addEventListener('click',()=>{if(confirm('Alle demo-invoer op dit apparaat wissen?')){localStorage.removeItem(KEY);initialize();say('Demo teruggezet naar de beginstand.')}});
function appendRows(root,items,callback){if(!items.length){root.innerHTML='<div class="empty">Nog geen aanvragen. Probeer de bezoekerskant.</div>';return}root.innerHTML=items.map(callback).join('')}
function validateEmail(v){return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v).trim())}


const KEY='mcc-vraagassistent-v1';
const initial=()=>({messages:[{role:'bot',text:'Welkom! Ik ben de demonstratie-assistent van Studio Noord. Vraag naar openingstijden, een afspraak of kennismaking. Voor andere vragen maak ik een ticket.'}],tickets:[],count:0});let db;
function initialize(){db=store.load(KEY,initial());renderChat();renderOwner()}
function classify(q){q=q.toLowerCase();if(/open|sluit|uur|tijd|zaterdag/.test(q))return 'opening';if(/prijs|kosten|kost|tarief|kennismaking/.test(q))return 'price';if(/afspraak|reserve|boek/.test(q)&&!/verzet|wijzig|annuleer|cancel/.test(q))return 'booking';return 'handoff'}
function respond(q){const topic=classify(q);const known={opening:'Onze voorbeeldopeningstijden: ma–vr 09:00–18:00 en zaterdag 10:00–16:00. Controleer echte tijden altijd op de website van de onderneming.',price:'In deze conceptdemo is een eerste kennismaking kosteloos. Dit is geen tariefbelofte van een bestaand bedrijf.',booking:'Je kunt een afspraak aanvragen via het contactformulier van een echte onderneming. Deze demo heeft geen live agenda en maakt geen afspraak.'};if(known[topic])return known[topic];const id=uid();db.tickets.unshift({id,question:q,status:'nieuw'});return `Dit kan ik niet veilig beantwoorden vanuit mijn beperkte kennisbank. Ik heb een DEMO-ticket ${id.slice(0,6).toUpperCase()} aangemaakt voor een medewerker. Er is niets verstuurd.`;}
function ask(q){q=q.trim().slice(0,280);if(!q)return;db.messages.push({role:'user',text:q});db.count++;db.messages.push({role:'bot',text:respond(q)});store.save(KEY,db);renderChat();renderOwner();}
function renderChat(){$('#chat-log').innerHTML=db.messages.map(m=>`<div class="bubble ${m.role==='bot'?'bot':'user'}">${escapeHtml(m.text)}</div>`).join('');$('#chat-log').scrollTop=$('#chat-log').scrollHeight}
$$('[data-question]').forEach(b=>b.onclick=()=>ask(b.dataset.question));
$('#chat-form').onsubmit=e=>{e.preventDefault();ask($('#chat-input').value);$('#chat-input').value=''};
function renderOwner(){$('#chat-count').textContent=db.count;$('#ticket-count').textContent=db.tickets.filter(t=>t.status==='nieuw').length;$('#resolved-count').textContent=db.tickets.filter(t=>t.status==='behandeld').length;$('#tickets-list').innerHTML=db.tickets.length?db.tickets.map(t=>`<div class="scenario"><span class="tag">${escapeHtml(t.id.slice(0,6).toUpperCase())}</span> <span class="state ${t.status==='nieuw'?'warn':''}">${escapeHtml(t.status)}</span><p>${escapeHtml(t.question)}</p>${t.status==='nieuw'?`<button class="outline" type="button" data-resolve="${t.id}">Markeer behandeld</button>`:''}</div>`).join(''):'<div class="empty">Nog geen overgedragen vragen. Probeer een onbekende vraag in de chat.</div>';$$('[data-resolve]').forEach(b=>b.onclick=()=>{db.tickets.find(t=>t.id===b.dataset.resolve).status='behandeld';store.save(KEY,db);renderOwner();say('Demo-ticket gemarkeerd als behandeld.')})}
initialize();
