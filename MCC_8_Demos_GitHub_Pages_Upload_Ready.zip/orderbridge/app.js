
const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
const escapeHtml=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const store={load(key,fallback){try{return JSON.parse(localStorage.getItem(key))??fallback}catch{return fallback}},save(key,val){localStorage.setItem(key,JSON.stringify(val))}};
const fmtDate=d=>{try{return new Date(d+'T12:00:00').toLocaleDateString('nl-NL',{day:'numeric',month:'short',year:'numeric'})}catch{return d}};
const nextISO=(days=1)=>{const d=new Date();d.setDate(d.getDate()+days);return d.toISOString().slice(0,10)};
const uid=()=>`${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`;
function say(text,isError=false){const box=$('#feedback');if(!box)return;box.textContent=text;box.classList.toggle('error',isError);box.hidden=false;window.clearTimeout(say.timer);say.timer=setTimeout(()=>{box.hidden=true},8000);box.scrollIntoView({block:'nearest',behavior:'smooth'})}
function setView(view){const owner=view==='owner';$('#owner-screen').hidden=!owner;$('#public-screen').hidden=owner;$$('[data-view]').forEach(b=>{b.classList.toggle('active',b.dataset.view===view);b.setAttribute('aria-pressed',String(b.dataset.view===view))});window.scrollTo({top:0,behavior:'instant'});if(owner)renderOwner();}
$$('[data-view]').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.view)));
$('#reset-demo').addEventListener('click',()=>{if(confirm('Alle demo-invoer op dit apparaat wissen?')){localStorage.removeItem(KEY);initialize();say('Demo teruggezet naar de beginstand.')}});
function appendRows(root,items,callback){if(!items.length){root.innerHTML='<div class="empty">Nog geen aanvragen. Probeer de bezoekerskant.</div>';return}root.innerHTML=items.map(callback).join('')}
function validateEmail(v){return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v).trim())}


const KEY='mcc-orderbridge-v1';
const initial=()=>({leads:[]});let db;
function initialize(){db=store.load(KEY,initial());renderOwner()}
$('#order-form').onsubmit=e=>{e.preventDefault();const name=$('#o-name').value.trim(),email=$('#o-email').value.trim(),message=$('#o-message').value.trim(),type=$('#o-type').value,budget=$('#o-budget').value;if(!name||!validateEmail(email)||message.length<12){say('Vul je naam, werkmail en een duidelijke aanvraag in.',true);return}db.leads.unshift({id:uid(),name,email,message,type,budget,stage:'nieuw',owner:type==='Website'?'Team Web':'Team Solutions',draftApproved:false,taskOpen:true,notes:[]});store.save(KEY,db);renderOwner();say('Conceptaanvraag lokaal verwerkt: CRM-lead, antwoordconcept en opvolgtaak aangemaakt. Bekijk de eigenaarweergave.');e.target.reset()};
function draft(lead){return `Beste ${lead.name.split(/\s+/)[0]},\n\nDank voor je aanvraag over ${lead.type.toLowerCase()}. We hebben je bericht ontvangen en bespreken graag de volgende stappen.\n\nDit is een DEMO-concept — niets is verstuurd.\nMCC Team`}
function renderOwner(){
 $('#crm-total').textContent=db.leads.length;$('#crm-followups').textContent=db.leads.filter(l=>l.taskOpen).length;$('#crm-ready').textContent=db.leads.filter(l=>l.draftApproved).length;
 $('#crm-list').innerHTML=db.leads.length?db.leads.map(l=>`<section class="scenario"><div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:15px"><div><span class="product-tag">${escapeHtml(l.type)} · ${escapeHtml(l.owner)}</span><h3 style="font:400 30px Georgia;margin:7px 0">${escapeHtml(l.name)}</h3><p style="margin:5px 0">${escapeHtml(l.email)}</p></div><span class="state ${l.stage==='nieuw'?'warn':''}">${escapeHtml(l.stage)}</span></div><p>${escapeHtml(l.message)}</p><p><strong>Budget:</strong> ${escapeHtml(l.budget)} · <strong>Opvolgtaak:</strong> ${l.taskOpen?'Open':'Afgevinkt'}</p><div style="padding:18px;background:#f0ece2;border:1px solid #ddd;white-space:pre-wrap;font-size:13px;margin:13px 0"><strong>Voorbereid e-mailconcept</strong> · ${l.draftApproved?'Beoordeeld':'Nog te controleren'}<br><br>${escapeHtml(draft(l))}</div><div class="inline-actions"><button type="button" data-id="${l.id}" data-act="qualify">Markeer gekwalificeerd</button><button type="button" data-id="${l.id}" data-act="draft">Beoordeel e-mailconcept</button><button type="button" data-id="${l.id}" data-act="task">${l.taskOpen?'Vink taak af':'Heropen taak'}</button></div></section>`).join(''):'<div class="empty">Geen leads. Vul als bezoeker het aanvraagformulier in.</div>';
 $$('[data-act]').forEach(b=>b.onclick=()=>{const lead=db.leads.find(l=>l.id===b.dataset.id);if(b.dataset.act==='qualify')lead.stage='gekwalificeerd';if(b.dataset.act==='draft')lead.draftApproved=true;if(b.dataset.act==='task')lead.taskOpen=!lead.taskOpen;store.save(KEY,db);renderOwner();say('Workflowstap bijgewerkt in de lokale CRM-simulatie. Geen echte e-mail verstuurd.')});
}
initialize();
