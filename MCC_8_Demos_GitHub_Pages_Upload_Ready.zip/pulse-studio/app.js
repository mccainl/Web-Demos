
const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
const escapeHtml=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const store={load(key,fallback){try{return JSON.parse(localStorage.getItem(key))??fallback}catch{return fallback}},save(key,val){localStorage.setItem(key,JSON.stringify(val))}};
const fmtDate=d=>{try{return new Date(d+'T12:00:00').toLocaleDateString('nl-NL',{day:'numeric',month:'short',year:'numeric'})}catch{return d}};
const nextISO=(days=1)=>{const d=new Date();d.setDate(d.getDate()+days);return d.toISOString().slice(0,10)};
const uid=()=>`${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`;
function say(text,isError=false){const box=$('#feedback');if(!box)return;box.textContent=text;box.classList.toggle('error',isError);box.hidden=false;window.clearTimeout(say.timer);say.timer=setTimeout(()=>{box.hidden=true},8000);box.scrollIntoView({block:'nearest',behavior:'smooth'})}
function setView(view){const owner=view==='owner';$('#owner-screen').hidden=!owner;$('#public-screen').hidden=owner;$$('[data-view]').forEach(b=>{b.classList.toggle('active',b.dataset.view===view);b.setAttribute('aria-pressed',String(b.dataset.view===view))});window.scrollTo({top:0,behavior:'instant'});if(owner)renderOwner();}
$$('[data-view]').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.view)));
$('#reset-demo').addEventListener('click',()=>{if(confirm('Alle demo-invoer op dit apparaat wissen?')){localStorage.removeItem(KEY);initialize();say('Demo teruggezet naar de beginstand.')}});
function appendRows(root,items,callback){if(!items.length){root.innerHTML='<div class="empty">Nog geen aanvragen. Probeer de bezoekerskant.</div>';return}root.innerHTML=items.map(callback).join('')}
function validateEmail(v){return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v).trim())}


const KEY='mcc-pulse-studio-v1';
const initial=()=>({classes:[
{id:'strength',name:'Strength Lab',when:'Dinsdag · 18:30',coach:'Milan',cap:10,photo:'strength.webp',desc:'Stevig, technisch en vol energie.'},
{id:'yoga',name:'Yoga Reset',when:'Woensdag · 08:00',coach:'Nora',cap:12,photo:'yoga.webp',desc:'Rust, mobiliteit en ruimte om op te laden.'},
{id:'hiit',name:'Pulse Circuit',when:'Donderdag · 19:15',coach:'Robin',cap:8,photo:'weights.webp',desc:'Dynamische intervallen in een kleine groep.'},
{id:'recovery',name:'Mobility Hour',when:'Zaterdag · 10:00',coach:'Noor',cap:14,photo:'stretch.webp',desc:'Beweging met aandacht voor herstel.'}
],bookings:[]});
let db;
function initialize(){db=store.load(KEY,initial());renderPublic();renderOwner()}
function activeFor(cid){return db.bookings.filter(b=>b.classId===cid&&b.status!=='geannuleerd')}
function renderPublic(){
 $('#class-cards').innerHTML=db.classes.map(c=>`<article class="tile"><img src="assets/${c.photo}" alt="${escapeHtml(c.name)} groepsles" loading="lazy"><div class="tile-content"><span class="product-tag">${escapeHtml(c.when)} · ${escapeHtml(c.coach)}</span><h3>${escapeHtml(c.name)}</h3><p>${escapeHtml(c.desc)}</p><p><strong>${Math.max(0,c.cap-activeFor(c.id).length)} plekken beschikbaar</strong></p><button data-pick="${c.id}" type="button">Reserveer een plek ↗</button></div></article>`).join('');
 $('#choose-class').innerHTML=db.classes.map(c=>`<option value="${c.id}">${escapeHtml(c.name)} · ${escapeHtml(c.when)}</option>`).join('');
 $$('[data-pick]').forEach(b=>b.onclick=()=>{$('#choose-class').value=b.dataset.pick;checkCapacity();$('#boek').scrollIntoView({behavior:'smooth'})});
 checkCapacity();
}
function checkCapacity(){const c=db.classes.find(x=>x.id===$('#choose-class').value);if(!c)return;let left=c.cap-activeFor(c.id).length;$('#class-capacity').textContent=`${left} beschikbare plekken · ${c.when}. ${left===0?'Volgeboekt: kies een andere les.':'Boeking is alleen een conceptdemo.'}`;}
$('#choose-class').onchange=checkCapacity;
$('#class-form').onsubmit=e=>{e.preventDefault();const c=db.classes.find(x=>x.id===$('#choose-class').value);const name=$('#member-name').value.trim();const email=$('#member-email').value.trim();if(!c||!name||!validateEmail(email)){say('Controleer je les, naam en e-mail.',true);return}if(activeFor(c.id).length>=c.cap){say('Deze les heeft geen vrije plekken meer.',true);return}if(activeFor(c.id).some(b=>b.email.toLowerCase()===email.toLowerCase())){say('Dit e-mailadres heeft al een plek in deze les.',true);return}db.bookings.unshift({id:uid(),classId:c.id,name,email,status:'geboekt'});store.save(KEY,db);renderPublic();say(`Je proefles ${c.name} staat als DEMO geboekt. Bekijk de inschrijving bij 'Eigenaar · Demo'.`);e.target.reset();checkCapacity();};
function renderOwner(){
 $('#total-bookings').textContent=db.bookings.filter(b=>b.status!=='geannuleerd').length;
 $('#total-classes').textContent=db.classes.length;
 $('#total-seats').textContent=db.classes.reduce((a,c)=>a+Math.max(0,c.cap-activeFor(c.id).length),0);
 $('#owner-classes').innerHTML=db.classes.map(c=>`<tr><td><strong>${escapeHtml(c.name)}</strong><br><span class="muted">Coach ${escapeHtml(c.coach)}</span></td><td>${escapeHtml(c.when)}</td><td>${activeFor(c.id).length} / ${c.cap}</td><td><div class="inline-actions"><button type="button" data-cap="${c.id}" data-step="-1" aria-label="Capaciteit ${escapeHtml(c.name)} verminderen">−</button><button type="button" data-cap="${c.id}" data-step="1" aria-label="Capaciteit ${escapeHtml(c.name)} verhogen">+</button></div></td></tr>`).join('');
 $('#owner-bookings').innerHTML=db.bookings.length?db.bookings.map(b=>{const c=db.classes.find(c=>c.id===b.classId);return `<tr><td><strong>${escapeHtml(b.name)}</strong><br><span class="muted">${escapeHtml(b.email)}</span></td><td>${escapeHtml(c?.name||'')}</td><td><span class="state ${b.status==='geannuleerd'?'off':''}">${escapeHtml(b.status)}</span></td><td><div class="inline-actions">${b.status!=='geannuleerd'?`<button data-booking="${b.id}" data-status="aanwezig">Aanwezig</button><button data-booking="${b.id}" data-status="geannuleerd">Annuleren</button>`:''}</div></td></tr>`}).join(''):'<tr><td colspan="4">Nog geen boekingen. Reserveer een proefles als bezoeker.</td></tr>';
 $$('[data-cap]').forEach(b=>b.onclick=()=>{const c=db.classes.find(c=>c.id===b.dataset.cap);const n=c.cap+Number(b.dataset.step);if(n<activeFor(c.id).length||n<1||n>35){say('Capaciteit moet tussen de geboekte plekken en 35 liggen.',true);return}c.cap=n;store.save(KEY,db);renderOwner();renderPublic()});
 $$('[data-booking]').forEach(b=>b.onclick=()=>{db.bookings.find(x=>x.id===b.dataset.booking).status=b.dataset.status;store.save(KEY,db);renderOwner();renderPublic();say('Status aangepast in demo-rooster.')});
}
initialize();
