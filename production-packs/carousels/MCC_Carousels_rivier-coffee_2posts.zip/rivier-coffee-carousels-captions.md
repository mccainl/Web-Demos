# Rivier Coffee — two supporting carousel posts (DRAFT ONLY, NOT SCHEDULED)

## 12:00 | Customer problem → MCC example

### Dutch

Een menukaart die hongerig maakt. ✦

Mensen willen snel een sfeer proeven, de menukaart bekijken en weten of er plek is. Bij een rommelige mobiele website grijpen ze naar de telefoon of zoeken ze een ander café.

In de interactieve **Rivier Coffee**-conceptdemo laten we zien hoe MCC dit probleem vertaalt naar een duidelijke, werkende ervaring. Bekijk zowel de bezoekerskant als het eigenaarsoverzicht.

🌐 **Test het project:** [VOEG GEVERIFIEERDE MCC GITHUB PAGES LINK TOE]
📖 **Lees het projectartikel:** [VOEG GEPUBLICEERDE MCC BLOG LINK TOE]
💬 Wil je zoiets voor jouw onderneming? Stuur **CLONE** naar **@mccai.nl** via Instagram DM.

*Conceptdemo met fictieve voorbeelddata, geen live klantproject.*

### English

Een horecawesite met een menu dat ook op de telefoon werkt. Experience both the customer side and the business owner's side in the **Rivier Coffee** interactive concept. Try the real demonstration and read its matching MCC article once both links have been verified. DM **CLONE** to @mccai.nl for a customized version. *Fictional portfolio demo; no live external integrations.*

Slides:
1. Een menukaart die hongerig maakt.
2. Laat je sfeer spreken op mobiel.
3. Laat gasten snel filteren en kiezen.
4. Maak de stap naar reserveren eenvoudig.
5. Een website die bij je zaak past.

## 18:00 | Guest experience + owner workflow → enquiry

### Dutch

Eén systeem. Twee kanten. ↗

De gast opent een sfeervolle menukaart, filtert koffie, ontbijt of lunch en plaatst een fictieve tafelreservering. De eigenaar ziet de aanvraag, kan haar bevestigen of annuleren en beheert of menu-items beschikbaar zijn.

Een professioneel digitaal product moet het werk van de klant én van de ondernemer makkelijker maken. Bekijk wat MCC kan ontwerpen en ontwikkelen.

🌐 **Live demo:** [VOEG GEVERIFIEERDE MCC GITHUB PAGES LINK TOE]
📖 **Het verhaal en de werking:** [VOEG GEPUBLICEERDE MCC BLOG LINK TOE]
💬 Eigen versie nodig? Stuur **CLONE** via Instagram DM naar **@mccai.nl**.

*Concept met lokale fictieve data, niet gekoppeld aan echte systemen.*

### English

One system, two perspectives. See how the customer action connects to the business workflow in **Rivier Coffee**. Explore our working concept and matching article once live. DM **CLONE** to @mccai.nl to discuss your own implementation. *Demo with safe sample data.*

Slides:
1. Een tafel reserveren zonder telefoontje.
2. De gast kiest de dag en tijd.
3. De reservering komt in het overzicht.
4. De eigenaar bevestigt met één actie.
5. Goed voor gast én ondernemer.

## Release blockers

- [ ] Public demo deployed on MCC-owned GitHub Pages and tested.
- [ ] Dutch and English project article live at mccai.nl and cross-linked.
- [ ] Captions updated with verified live URLs, link-in-bio alternative on Instagram.
- [ ] Carousel assets reviewed and approved by the owner.
- [ ] No Reel creation until all eight project demonstrations and supporting posts are ready.
- [ ] No social scheduling without fresh, explicit owner approval.
