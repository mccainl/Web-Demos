# Pulse Studio — two supporting carousel posts (DRAFT ONLY, NOT SCHEDULED)

## 12:00 | Customer problem → MCC example

### Dutch

Je sportles begint vóór de les. ✦

Een sportstudio krijgt vragen over tijden, beschikbare plekken en inschrijvingen. Zonder gekoppelde boekingsreis is elk verzoek een extra taak voor het team.

In de interactieve **Pulse Studio**-conceptdemo laten we zien hoe MCC dit probleem vertaalt naar een duidelijke, werkende ervaring. Bekijk zowel de bezoekerskant als het eigenaarsoverzicht.

🌐 **Test het project:** [VOEG GEVERIFIEERDE MCC GITHUB PAGES LINK TOE]
📖 **Lees het projectartikel:** [VOEG GEPUBLICEERDE MCC BLOG LINK TOE]
💬 Wil je zoiets voor jouw onderneming? Stuur **CLONE** naar **@mccai.nl** via Instagram DM.

*Conceptdemo met fictieve voorbeelddata, geen live klantproject.*

### English

Een fitnesswebsite waar proeflessen direct geboekt kunnen worden. Experience both the customer side and the business owner's side in the **Pulse Studio** interactive concept. Try the real demonstration and read its matching MCC article once both links have been verified. DM **CLONE** to @mccai.nl for a customized version. *Fictional portfolio demo; no live external integrations.*

Slides:
1. Je sportles begint vóór de les.
2. De juiste les snel kunnen vinden.
3. Direct zien hoeveel plekken er vrij zijn.
4. Een proefles boeken zonder telefoontje.
5. De drempel wordt lager.

## 18:00 | Guest experience + owner workflow → enquiry

### Dutch

Eén systeem. Twee kanten. ↗

De sporter bekijkt lessen met trainer, tijd en resterende capaciteit en boekt een fictieve proefles. In de eigenaarweergave verschijnt de inschrijving en kan een beheerder aanwezigheid markeren, annuleren of lescapaciteit aanpassen.

Een professioneel digitaal product moet het werk van de klant én van de ondernemer makkelijker maken. Bekijk wat MCC kan ontwerpen en ontwikkelen.

🌐 **Live demo:** [VOEG GEVERIFIEERDE MCC GITHUB PAGES LINK TOE]
📖 **Het verhaal en de werking:** [VOEG GEPUBLICEERDE MCC BLOG LINK TOE]
💬 Eigen versie nodig? Stuur **CLONE** via Instagram DM naar **@mccai.nl**.

*Concept met lokale fictieve data, niet gekoppeld aan echte systemen.*

### English

One system, two perspectives. See how the customer action connects to the business workflow in **Pulse Studio**. Explore our working concept and matching article once live. DM **CLONE** to @mccai.nl to discuss your own implementation. *Demo with safe sample data.*

Slides:
1. Minder vragen. Meer overzicht.
2. Een klant kiest een les.
3. De inschrijving verschijnt direct.
4. De coach ziet bezetting en aanwezigheid.
5. Een website die de studio ondersteunt.

## Release blockers

- [ ] Public demo deployed on MCC-owned GitHub Pages and tested.
- [ ] Dutch and English project article live at mccai.nl and cross-linked.
- [ ] Captions updated with verified live URLs, link-in-bio alternative on Instagram.
- [ ] Carousel assets reviewed and approved by the owner.
- [ ] No Reel creation until all eight project demonstrations and supporting posts are ready.
- [ ] No social scheduling without fresh, explicit owner approval.
