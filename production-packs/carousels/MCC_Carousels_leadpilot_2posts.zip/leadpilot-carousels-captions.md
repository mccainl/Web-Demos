# LeadPilot — two supporting carousel posts (DRAFT ONLY, NOT SCHEDULED)

## 12:00 | Customer problem → MCC example

### Dutch

Een aanvraag is nog geen opvolging. ✦

Een contactformulier maakt nog geen salesproces. Leads kunnen versnipperen tussen e-mail, taken, notities en gesprekken. Een team heeft één plek nodig om alles terug te vinden.

In de interactieve **LeadPilot**-conceptdemo laten we zien hoe MCC dit probleem vertaalt naar een duidelijke, werkende ervaring. Bekijk zowel de bezoekerskant als het eigenaarsoverzicht.

🌐 **Test het project:** [VOEG GEVERIFIEERDE MCC GITHUB PAGES LINK TOE]
📖 **Lees het projectartikel:** [VOEG GEPUBLICEERDE MCC BLOG LINK TOE]
💬 Wil je zoiets voor jouw onderneming? Stuur **CLONE** naar **@mccai.nl** via Instagram DM.

*Conceptdemo met fictieve voorbeelddata, geen live klantproject.*

### English

Van klantaanvraag naar overzichtelijke opvolging. Experience both the customer side and the business owner's side in the **LeadPilot** interactive concept. Try the real demonstration and read its matching MCC article once both links have been verified. DM **CLONE** to @mccai.nl for a customized version. *Fictional portfolio demo; no live external integrations.*

Slides:
1. Een aanvraag is nog geen opvolging.
2. Een losse e-mail heeft geen eigenaar.
3. Maak van het contactformulier een intake.
4. De pijplijn laat de volgende stap zien.
5. Werk beter met je klanten samen.

## 18:00 | Guest experience + owner workflow → enquiry

### Dutch

Eén systeem. Twee kanten. ↗

Een potentiële klant verstuurt een projectbrief. De ondernemer krijgt een lokale demo-lead, verplaatst die door de pipeline, slaat notities op en plant opvolging in de taakweergave.

Een professioneel digitaal product moet het werk van de klant én van de ondernemer makkelijker maken. Bekijk wat MCC kan ontwerpen en ontwikkelen.

🌐 **Live demo:** [VOEG GEVERIFIEERDE MCC GITHUB PAGES LINK TOE]
📖 **Het verhaal en de werking:** [VOEG GEPUBLICEERDE MCC BLOG LINK TOE]
💬 Eigen versie nodig? Stuur **CLONE** via Instagram DM naar **@mccai.nl**.

*Concept met lokale fictieve data, niet gekoppeld aan echte systemen.*

### English

One system, two perspectives. See how the customer action connects to the business workflow in **LeadPilot**. Explore our working concept and matching article once live. DM **CLONE** to @mccai.nl to discuss your own implementation. *Demo with safe sample data.*

Slides:
1. Eén systeem. Twee perspectieven.
2. De klant vertelt wat hij zoekt.
3. Het team ontvangt één helder klantrecord.
4. Taken, notities en status blijven bij elkaar.
5. MCC bouwt webapps op maat.

## Release blockers

- [ ] Public demo deployed on MCC-owned GitHub Pages and tested.
- [ ] Dutch and English project article live at mccai.nl and cross-linked.
- [ ] Captions updated with verified live URLs, link-in-bio alternative on Instagram.
- [ ] Carousel assets reviewed and approved by the owner.
- [ ] No Reel creation until all eight project demonstrations and supporting posts are ready.
- [ ] No social scheduling without fresh, explicit owner approval.
