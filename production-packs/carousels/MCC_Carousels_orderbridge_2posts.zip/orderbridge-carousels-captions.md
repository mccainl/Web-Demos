# OrderBridge — two supporting carousel posts (DRAFT ONLY, NOT SCHEDULED)

## 12:00 | Customer problem → MCC example

### Dutch

Een formulier is geen leadproces. ✦

Nieuwe aanvragen blijven vaak in mailboxen hangen. Wie neemt ze op, welk antwoord is passend en wanneer volgt iemand op? Zonder systeem ontstaat tijdverlies en onduidelijkheid.

In de interactieve **OrderBridge**-conceptdemo laten we zien hoe MCC dit probleem vertaalt naar een duidelijke, werkende ervaring. Bekijk zowel de bezoekerskant als het eigenaarsoverzicht.

🌐 **Test het project:** [VOEG GEVERIFIEERDE MCC GITHUB PAGES LINK TOE]
📖 **Lees het projectartikel:** [VOEG GEPUBLICEERDE MCC BLOG LINK TOE]
💬 Wil je zoiets voor jouw onderneming? Stuur **CLONE** naar **@mccai.nl** via Instagram DM.

*Conceptdemo met fictieve voorbeelddata, geen live klantproject.*

### English

Een contactformulier is pas waardevol met een opvolgproces. Experience both the customer side and the business owner's side in the **OrderBridge** interactive concept. Try the real demonstration and read its matching MCC article once both links have been verified. DM **CLONE** to @mccai.nl for a customized version. *Fictional portfolio demo; no live external integrations.*

Slides:
1. Een formulier is geen leadproces.
2. Iedere aanvraag verdient opvolging.
3. Het systeem kiest het juiste team.
4. Een conceptantwoord staat klaar.
5. Van contact naar actie.

## 18:00 | Guest experience + owner workflow → enquiry

### Dutch

Eén systeem. Twee kanten. ↗

De bezoeker vult een concreet projectverzoek in. De simulatie maakt een CRM-lead, kiest een voorbeeldteam en bereidt een e-mailconcept met opvolgtaak voor. De ondernemer beoordeelt het concept en kan de lead kwalificeren en de taak afvinken.

Een professioneel digitaal product moet het werk van de klant én van de ondernemer makkelijker maken. Bekijk wat MCC kan ontwerpen en ontwikkelen.

🌐 **Live demo:** [VOEG GEVERIFIEERDE MCC GITHUB PAGES LINK TOE]
📖 **Het verhaal en de werking:** [VOEG GEPUBLICEERDE MCC BLOG LINK TOE]
💬 Eigen versie nodig? Stuur **CLONE** via Instagram DM naar **@mccai.nl**.

*Concept met lokale fictieve data, niet gekoppeld aan echte systemen.*

### English

One system, two perspectives. See how the customer action connects to the business workflow in **OrderBridge**. Explore our working concept and matching article once live. DM **CLONE** to @mccai.nl to discuss your own implementation. *Demo with safe sample data.*

Slides:
1. Meer aanvragen? Houd overzicht.
2. Nieuwe leads komen gestructureerd binnen.
3. CRM en opvolgtaak worden voorbereid.
4. Je team blijft aan het stuur.
5. MCC verbindt de losse stappen.

## Release blockers

- [ ] Public demo deployed on MCC-owned GitHub Pages and tested.
- [ ] Dutch and English project article live at mccai.nl and cross-linked.
- [ ] Captions updated with verified live URLs, link-in-bio alternative on Instagram.
- [ ] Carousel assets reviewed and approved by the owner.
- [ ] No Reel creation until all eight project demonstrations and supporting posts are ready.
- [ ] No social scheduling without fresh, explicit owner approval.
