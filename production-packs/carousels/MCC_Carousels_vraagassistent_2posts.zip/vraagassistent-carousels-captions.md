# VraagAssistent — two supporting carousel posts (DRAFT ONLY, NOT SCHEDULED)

## 12:00 | Customer problem → MCC example

### Dutch

Wat gebeurt er met vragen na sluitingstijd? ✦

Veel klantvragen komen buiten kantooruren binnen. Een assistent kan helpen met bekende bedrijfsinformatie, maar moet bij onzekerheid niet improviseren. Vertrouwen en menselijke overdracht zijn essentieel.

In de interactieve **VraagAssistent**-conceptdemo laten we zien hoe MCC dit probleem vertaalt naar een duidelijke, werkende ervaring. Bekijk zowel de bezoekerskant als het eigenaarsoverzicht.

🌐 **Test het project:** [VOEG GEVERIFIEERDE MCC GITHUB PAGES LINK TOE]
📖 **Lees het projectartikel:** [VOEG GEPUBLICEERDE MCC BLOG LINK TOE]
💬 Wil je zoiets voor jouw onderneming? Stuur **CLONE** naar **@mccai.nl** via Instagram DM.

*Conceptdemo met fictieve voorbeelddata, geen live klantproject.*

### English

Een digitale assistent die weet wanneer hij moet doorverwijzen. Experience both the customer side and the business owner's side in the **VraagAssistent** interactive concept. Try the real demonstration and read its matching MCC article once both links have been verified. DM **CLONE** to @mccai.nl for a customized version. *Fictional portfolio demo; no live external integrations.*

Slides:
1. Wat gebeurt er met vragen na sluitingstijd?
2. Een bezoeker stelt een herkenbare vraag.
3. Gecontroleerde informatie geeft antwoord.
4. Onbekend? Geen gok. Wel een ticket.
5. AI hoort ook zijn grenzen te kennen.

## 18:00 | Guest experience + owner workflow → enquiry

### Dutch

Eén systeem. Twee kanten. ↗

De bezoeker stelt een vraag over openingstijden, tarieven of afspraken. De kleine vaste kennisbank geeft een begrensd voorbeeldantwoord. Een onbekende vraag wordt een supportticket dat de eigenaar in de demo kan behandelen.

Een professioneel digitaal product moet het werk van de klant én van de ondernemer makkelijker maken. Bekijk wat MCC kan ontwerpen en ontwikkelen.

🌐 **Live demo:** [VOEG GEVERIFIEERDE MCC GITHUB PAGES LINK TOE]
📖 **Het verhaal en de werking:** [VOEG GEPUBLICEERDE MCC BLOG LINK TOE]
💬 Eigen versie nodig? Stuur **CLONE** via Instagram DM naar **@mccai.nl**.

*Concept met lokale fictieve data, niet gekoppeld aan echte systemen.*

### English

One system, two perspectives. See how the customer action connects to the business workflow in **VraagAssistent**. Explore our working concept and matching article once live. DM **CLONE** to @mccai.nl to discuss your own implementation. *Demo with safe sample data.*

Slides:
1. AI die antwoordt én doorgeeft.
2. De klant hoeft niet direct te bellen.
3. Bekende informatie verschijnt meteen.
4. Lastige vragen gaan naar het team.
5. Slimme service, met controle.

## Release blockers

- [ ] Public demo deployed on MCC-owned GitHub Pages and tested.
- [ ] Dutch and English project article live at mccai.nl and cross-linked.
- [ ] Captions updated with verified live URLs, link-in-bio alternative on Instagram.
- [ ] Carousel assets reviewed and approved by the owner.
- [ ] No Reel creation until all eight project demonstrations and supporting posts are ready.
- [ ] No social scheduling without fresh, explicit owner approval.
