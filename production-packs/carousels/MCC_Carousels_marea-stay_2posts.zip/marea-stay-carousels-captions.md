# Marea Stay — two supporting carousel posts (DRAFT ONLY, NOT SCHEDULED)

## 12:00 | Customer problem → MCC example

### Dutch

Een mooie hotelwebsite is nog geen boeking. ✦

Bij een boutique hotel telt de eerste indruk, maar zonder helder kamer- en boekingsproces haakt een bezoeker af. Een eigenaar heeft tegelijk behoefte aan overzicht over aanvragen en bezetting.

In de interactieve **Marea Stay**-conceptdemo laten we zien hoe MCC dit probleem vertaalt naar een duidelijke, werkende ervaring. Bekijk zowel de bezoekerskant als het eigenaarsoverzicht.

🌐 **Test het project:** [VOEG GEVERIFIEERDE MCC GITHUB PAGES LINK TOE]
📖 **Lees het projectartikel:** [VOEG GEPUBLICEERDE MCC BLOG LINK TOE]
💬 Wil je zoiets voor jouw onderneming? Stuur **CLONE** naar **@mccai.nl** via Instagram DM.

*Conceptdemo met fictieve voorbeelddata, geen live klantproject.*

### English

Een mooie hotelwebsite moet méér doen dan inspireren. Experience both the customer side and the business owner's side in the **Marea Stay** interactive concept. Try the real demonstration and read its matching MCC article once both links have been verified. DM **CLONE** to @mccai.nl for a customized version. *Fictional portfolio demo; no live external integrations.*

Slides:
1. Een mooie hotelwebsite is nog geen boeking.
2. Een bezoeker wil niet zoeken naar de volgende stap.
3. Kies data, gasten en een kamer zonder verwarring.
4. De boeking staat direct in het overzicht.
5. Maak van inspiratie een heldere gastreis.

## 18:00 | Guest experience + owner workflow → enquiry

### Dutch

Eén systeem. Twee kanten. ↗

De gast ziet drie suites, kiest data en aantal gasten en bevestigt een fictieve reservering. De eigenaar ziet die direct in het browser-lokale dashboard en kan haar als ingecheckt of geannuleerd markeren.

Een professioneel digitaal product moet het werk van de klant én van de ondernemer makkelijker maken. Bekijk wat MCC kan ontwerpen en ontwikkelen.

🌐 **Live demo:** [VOEG GEVERIFIEERDE MCC GITHUB PAGES LINK TOE]
📖 **Het verhaal en de werking:** [VOEG GEPUBLICEERDE MCC BLOG LINK TOE]
💬 Eigen versie nodig? Stuur **CLONE** via Instagram DM naar **@mccai.nl**.

*Concept met lokale fictieve data, niet gekoppeld aan echte systemen.*

### English

One system, two perspectives. See how the customer action connects to the business workflow in **Marea Stay**. Explore our working concept and matching article once live. DM **CLONE** to @mccai.nl to discuss your own implementation. *Demo with safe sample data.*

Slides:
1. Een gast boekt. De eigenaar ziet het.
2. 01 / De gast ziet de suites en prijzen.
3. 02 / Een reservering wordt aangemaakt.
4. 03 / De eigenaar beheert de status.
5. Twee kanten. Eén consistente ervaring.

## Release blockers

- [ ] Public demo deployed on MCC-owned GitHub Pages and tested.
- [ ] Dutch and English project article live at mccai.nl and cross-linked.
- [ ] Captions updated with verified live URLs, link-in-bio alternative on Instagram.
- [ ] Carousel assets reviewed and approved by the owner.
- [ ] No Reel creation until all eight project demonstrations and supporting posts are ready.
- [ ] No social scheduling without fresh, explicit owner approval.
