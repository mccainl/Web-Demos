# FactuurFlow — two supporting carousel posts (DRAFT ONLY, NOT SCHEDULED)

## 12:00 | Customer problem → MCC example

### Dutch

Hoeveel tijd kost facturen overtypen? ✦

Bij handmatige factuurverwerking worden regels, bedragen en leveranciers telkens opnieuw overgenomen. Fouten vallen soms pas veel later op. Automatisering moet juist inzicht geven in uitzonderingen.

In de interactieve **FactuurFlow**-conceptdemo laten we zien hoe MCC dit probleem vertaalt naar een duidelijke, werkende ervaring. Bekijk zowel de bezoekerskant als het eigenaarsoverzicht.

🌐 **Test het project:** [VOEG GEVERIFIEERDE MCC GITHUB PAGES LINK TOE]
📖 **Lees het projectartikel:** [VOEG GEPUBLICEERDE MCC BLOG LINK TOE]
💬 Wil je zoiets voor jouw onderneming? Stuur **CLONE** naar **@mccai.nl** via Instagram DM.

*Conceptdemo met fictieve voorbeelddata, geen live klantproject.*

### English

Facturen sneller verwerken zonder de controle te verliezen. Experience both the customer side and the business owner's side in the **FactuurFlow** interactive concept. Try the real demonstration and read its matching MCC article once both links have been verified. DM **CLONE** to @mccai.nl for a customized version. *Fictional portfolio demo; no live external integrations.*

Slides:
1. Hoeveel tijd kost facturen overtypen?
2. 01 / Een factuur komt binnen.
3. 02 / Velden en bedragen worden gecontroleerd.
4. 03 / Een fout wordt direct gemarkeerd.
5. Automatisering mét menselijke controle.

## 18:00 | Guest experience + owner workflow → enquiry

### Dutch

Eén systeem. Twee kanten. ↗

De gebruiker kiest een veilige voorbeeldfactuur. De demo controleert de bekende regels en het bedrag en markeert een afwijkend totaal. In het eigenaarsdashboard corrigeert de ondernemer de invoer en keurt die pas goed nadat de controle slaagt.

Een professioneel digitaal product moet het werk van de klant én van de ondernemer makkelijker maken. Bekijk wat MCC kan ontwerpen en ontwikkelen.

🌐 **Live demo:** [VOEG GEVERIFIEERDE MCC GITHUB PAGES LINK TOE]
📖 **Het verhaal en de werking:** [VOEG GEPUBLICEERDE MCC BLOG LINK TOE]
💬 Eigen versie nodig? Stuur **CLONE** via Instagram DM naar **@mccai.nl**.

*Concept met lokale fictieve data, niet gekoppeld aan echte systemen.*

### English

One system, two perspectives. See how the customer action connects to the business workflow in **FactuurFlow**. Explore our working concept and matching article once live. DM **CLONE** to @mccai.nl to discuss your own implementation. *Demo with safe sample data.*

Slides:
1. Een fout is geen probleem. Onzichtbare fouten wel.
2. Het afwijkende totaal wordt gevonden.
3. De ondernemer corrigeert het bedrag.
4. Pas daarna kan de factuur door.
5. Van losse controles naar één proces.

## Release blockers

- [ ] Public demo deployed on MCC-owned GitHub Pages and tested.
- [ ] Dutch and English project article live at mccai.nl and cross-linked.
- [ ] Captions updated with verified live URLs, link-in-bio alternative on Instagram.
- [ ] Carousel assets reviewed and approved by the owner.
- [ ] No Reel creation until all eight project demonstrations and supporting posts are ready.
- [ ] No social scheduling without fresh, explicit owner approval.
