# Haven Interiors — two supporting carousel posts (DRAFT ONLY, NOT SCHEDULED)

## 12:00 | Customer problem → MCC example

### Dutch

Een portfolio dat bezoekers laat dromen. ✦

Een interieurstudio heeft veel te laten zien, maar potentiële klanten willen ook hun smaak kunnen verzamelen en precies aangeven wat zij zoeken. Een statische galerij laat te vaak onduidelijkheid achter.

In de interactieve **Haven Interiors**-conceptdemo laten we zien hoe MCC dit probleem vertaalt naar een duidelijke, werkende ervaring. Bekijk zowel de bezoekerskant als het eigenaarsoverzicht.

🌐 **Test het project:** [VOEG GEVERIFIEERDE MCC GITHUB PAGES LINK TOE]
📖 **Lees het projectartikel:** [VOEG GEPUBLICEERDE MCC BLOG LINK TOE]
💬 Wil je zoiets voor jouw onderneming? Stuur **CLONE** naar **@mccai.nl** via Instagram DM.

*Conceptdemo met fictieve voorbeelddata, geen live klantproject.*

### English

Een interieurportfolio dat niet alleen inspireert maar aanvragen oplevert. Experience both the customer side and the business owner's side in the **Haven Interiors** interactive concept. Try the real demonstration and read its matching MCC article once both links have been verified. DM **CLONE** to @mccai.nl for a customized version. *Fictional portfolio demo; no live external integrations.*

Slides:
1. Een portfolio dat bezoekers laat dromen.
2. Een rustige collectie maakt het verschil.
3. Filter op woon-, slaap- en eetruimte.
4. Bewaar wat bij jouw interieur past.
5. Van inspiratie naar klantgesprek.

## 18:00 | Guest experience + owner workflow → enquiry

### Dutch

Eén systeem. Twee kanten. ↗

Een bezoeker filtert woonruimtes, bewaart favoriete stijlen op een lokaal moodboard en stuurt een conceptaanvraag. De studio-eigenaar ziet welke stijlen de klant koos, markeert de aanvraag als opgevolgd en kan collectie-items verbergen.

Een professioneel digitaal product moet het werk van de klant én van de ondernemer makkelijker maken. Bekijk wat MCC kan ontwerpen en ontwikkelen.

🌐 **Live demo:** [VOEG GEVERIFIEERDE MCC GITHUB PAGES LINK TOE]
📖 **Het verhaal en de werking:** [VOEG GEPUBLICEERDE MCC BLOG LINK TOE]
💬 Eigen versie nodig? Stuur **CLONE** via Instagram DM naar **@mccai.nl**.

*Concept met lokale fictieve data, niet gekoppeld aan echte systemen.*

### English

One system, two perspectives. See how the customer action connects to the business workflow in **Haven Interiors**. Explore our working concept and matching article once live. DM **CLONE** to @mccai.nl to discuss your own implementation. *Demo with safe sample data.*

Slides:
1. Een moodboard is het begin van een aanvraag.
2. Bezoekers kiezen hun favoriete stijlen.
3. De selectie gaat mee met het formulier.
4. De studio krijgt een duidelijke briefing.
5. MCC bouwt ervaringen die doorwerken.

## Release blockers

- [ ] Public demo deployed on MCC-owned GitHub Pages and tested.
- [ ] Dutch and English project article live at mccai.nl and cross-linked.
- [ ] Captions updated with verified live URLs, link-in-bio alternative on Instagram.
- [ ] Carousel assets reviewed and approved by the owner.
- [ ] No Reel creation until all eight project demonstrations and supporting posts are ready.
- [ ] No social scheduling without fresh, explicit owner approval.
