---
title: "Van websiteaanvraag naar echte opvolging: maak kennis met LeadPilot"
slug: leadpilot-van-aanvraag-naar-opvolging
locale: nl
status: draft
publication: pending
category: webapplicaties
canonical: pending-live-url
summary: "Bekijk hoe een goede webapp aanvragen uit een formulier direct in een overzichtelijke pijplijn zet, inclusief taken en vervolgacties."
project_slug: leadpilot
project_type: conceptdemo
---

# Van websiteaanvraag naar echte opvolging: maak kennis met LeadPilot

Een nieuwe klantaanvraag is vaak een goed begin — maar wat gebeurt er daarna? Een contactformulier dat alleen een e-mail verstuurt, kan zorgen voor losse notities, vergeten terugbelmomenten en onduidelijkheid over wie wat oppakt. Precies dat dagelijkse probleem staat centraal in ons conceptproject **LeadPilot**.

Met LeadPilot laten we zien hoe MCC een **webapplicatie op maat** kan ontwikkelen: één ervaring voor degene die contact opneemt en een compleet andere, maar verbonden ervaring voor de ondernemer die de aanvraag moet opvolgen.

## De klantkant: duidelijk en toegankelijk

In de voorbeeldwebsite beschrijft een bezoeker het project, kiest hij of zij de gewenste dienst — website, webapp, automatisering of AI-assistent — en vult optioneel budget en gewenste start in. Na het indienen verschijnt een bevestiging. Er is geen ingewikkelde intakeprocedure nodig om interesse kenbaar te maken.

De ingezonden testaanvraag verschijnt direct in het eigenaarsoverzicht. Daarmee wordt het verschil zichtbaar tussen **een formulier dat gegevens verzamelt** en **een proces dat de volgende stap organiseert**.

## De ondernemerskant: overzicht en opvolging

In de LeadPilot demo kan de ondernemer:

- binnengekomen aanvragen bekijken en doorzoeken;
- een project van *Nieuw* naar *In gesprek*, *Voorstel* of *Gewonnen* verplaatsen;
- contactgegevens, dienst, budget en projectomschrijving teruglezen;
- interne notities toevoegen, aanpassen en bewaren;
- gerichte opvolgtaken aanmaken en afvinken;
- wijzigingen terugzien in de activiteitengeschiedenis.

De belangrijkste boodschap is niet dat je nóg een dashboard nodig hebt. Het gaat erom dat de **volgende concrete actie** niet verloren gaat zodra een klant op 'Versturen' klikt.

## Waarom een webapp op maat?

Een organisatie heeft vaak een unieke combinatie van aanvragen, klantinformatie, interne processen en afspraken. Met een passende webapp kan MCC die stappen rondom het bedrijf organiseren in plaats van het bedrijf te dwingen zich aan te passen aan een standaardtool.

Denk aan een projectstudio die meerdere diensten aanbiedt, een installatiebedrijf dat offertes voorbereidt, of een creatief bureau met een klein team. Welke functies daarbij echt nodig zijn, bepalen we samen op basis van werkprocessen, privacy, kosten en bestaande systemen.

## Probeer de interactieve conceptdemo

**Interactieve LeadPilot demo:** [wordt ingevuld na publicatie op MCC GitHub Pages]

De demo heeft twee tabbladen: **Voor de klant** en **Voor de ondernemer**. Gebruik gerust fictieve gegevens om zelf te ervaren hoe één aanvraag zichtbaar wordt in de pijplijn.

> **Transparantie:** LeadPilot is op dit moment een interactieve conceptdemo met fictieve gegevens. Nieuwe testaanvragen worden alleen in de eigen browser bewaard. Er worden geen echte e-mails verzonden, geen externe CRM-systemen aangeroepen en geen persoonlijke gegevens verwerkt op onze server. Resultaten op het scherm zijn geen claims over echte klanten of gerealiseerde besparingen.

## Een vergelijkbaar systeem voor jouw bedrijf?

MCC bouwt websites, webapplicaties en automatiseringen die bij echte werkwijzen passen. Wil je een eigen versie van dit concept — met jouw formulieren, rollen en bedrijfsprocessen? Stuur **CLONE** via Instagram DM naar **[@mccai.nl](https://www.instagram.com/mccai.nl/)**. We bespreken graag de mogelijkheden en wat er nodig is voor een veilige productieversie.

**MCC — Maak ondernemen eenvoudiger.**
