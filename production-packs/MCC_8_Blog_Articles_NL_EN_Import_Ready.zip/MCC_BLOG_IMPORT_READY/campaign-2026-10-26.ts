/** Staged campaign articles. DO NOT PUBLISH until each corresponding demo is publicly live, verified, and cross-linked. */
import type { Post } from './blog';
import type { PostText } from './blog-translations';

export const campaign2026Posts: Post[] = [
  {
    "slug": "marea-stay",
    "title": "Marea Stay — MCC interactive concept",
    "date": "2026-10-26",
    "lang": "en",
    "summary": "A beautiful hotel website becomes more useful when visitors understand the property and can move directly from interest to booking. Marea Stay is a fictional boutique-hotel concept built by MCC t",
    "tags": [
      "Websites",
      "Interactive demo",
      "MCC portfolio"
    ],
    "body": [
      "A beautiful hotel website becomes more useful when visitors understand the property and can move directly from interest to booking. Marea Stay is a fictional boutique-hotel concept built by MCC to demonstrate both sides of that journey: the guest's experience and the owner's operational view.",
      "## The guest journey",
      "Visitors can explore three different suites, select check-in and check-out dates, choose their party size, see simulated room availability, calculate a total price, and make a sample booking. The site works on mobile as well as desktop.",
      "## The owner experience",
      "The interactive owner dashboard lists sample reservations and any bookings created in the same browser. It shows room, dates, guest count and booking value, and supports check-in, cancellation and resetting the sample data.",
      "## What works — and what is simulated",
      "Date validation, overlapping-booking checks, price calculations and local booking status changes are functional. This is not a real hotel reservation service: there is no shared inventory, payment processing, email delivery or hotel system integration. Demo data stays in the visitor's browser. Real deployments would need a production backend, stronger validation, security, privacy and integrations.",
      "## Want your own version?",
      "MCC builds distinctive websites and tailored digital workflows to match a business's real needs. Explore the interactive demo once its MCC GitHub Pages link is published, or DM CLONE to [@mccai.nl](https://www.instagram.com/mccai.nl/) to discuss your own customized project.",
      "*Marea Stay is a fictional MCC portfolio demo. All rooms, rates, people and bookings are sample data.*"
    ],
    "draft": true
  },
  {
    "slug": "factuurflow",
    "title": "FactuurFlow — MCC interactive concept",
    "date": "2026-10-27",
    "lang": "en",
    "summary": "An MCC interactive portfolio concept · fictional brand and safe sample data",
    "tags": [
      "Automation",
      "Interactive demo",
      "MCC portfolio"
    ],
    "body": [
      "An MCC interactive portfolio concept · fictional brand and safe sample data",
      "## Why businesses need more than attractive interfaces",
      "Accounts teams often retype supplier names, line items and totals from one system into another. Manual work consumes attention, while inconsistent numbers can slip past until month-end. A useful automation does more than copy: it isolates exceptions for a person to review.",
      "## Try the customer experience and the owner’s perspective",
      "A visitor selects one of three safe sample invoices. The deterministic simulator recalculates its known line items and tax and identifies a deliberately incorrect total. In the owner view, the operator can correct the amount and approve the concept only after it passes validation.",
      "The goal is to make the product useful for both parties. Visitors should understand their next step and the people running the business should be able to see, manage and verify the outcome.",
      "## What you can actually try",
      "- **Sample invoice intake with predefined, fictional data**",
      "- **Recalculation and automatic detection of mismatched totals**",
      "- **Human correction, gated approval and a local audit log**",
      "## What is functional, and what is simulated?",
      "The forms, controls, filters and state transitions respond as described. There is no live OCR engine, accounting-system connection or real financial posting. The files and values are illustrative, and all activity stays in the visitor’s browser. This is a demonstration of MCC’s design and implementation approach, not a claim of work completed for a named paying client or a verified uplift in revenue.",
      "## What MCC could build for your company",
      "For production, MCC could connect secure document extraction, supplier verification, VAT checks, accounting integrations and role-based approvals—with an audit trail and safe failure handling.",
      "A real implementation begins with your existing operations: permissions, data retention, reliability, integration requirements, the customer experience and the points where a person must remain in control. MCC then scopes the right architecture before developing and testing a production system.",
      "## Explore the concept and request your own version",
      "Interactive demo: `[ADD THE VERIFIED MCC GITHUB PAGES URL BEFORE PUBLICATION]`",
      "Dutch companion article: `[ADD VERIFIED MCC ARTICLE URL BEFORE PUBLICATION]`",
      "Want a similar solution tailored to your business? DM CLONE to @mccai.nl and mention FactuurFlow. We’ll discuss what needs to be changed for your real workflow.",
      "*MCC — Make business easier.*"
    ],
    "draft": true
  },
  {
    "slug": "haven-interiors",
    "title": "Haven Interiors — MCC interactive concept",
    "date": "2026-10-28",
    "lang": "en",
    "summary": "An MCC interactive portfolio concept · fictional brand and safe sample data",
    "tags": [
      "Websites",
      "Interactive demo",
      "MCC portfolio"
    ],
    "body": [
      "An MCC interactive portfolio concept · fictional brand and safe sample data",
      "## Why businesses need more than attractive interfaces",
      "An interior studio has more to communicate than a gallery can contain. Prospective clients want to collect visual references and share the room they need help with. A static portfolio rarely carries those preferences into the first conversation.",
      "## Try the customer experience and the owner’s perspective",
      "The visitor explores collections by room, saves favourite styles to a moodboard and submits an example design brief. The studio owner sees the selected inspirations alongside the enquiry, can mark it as followed up and can control which collections are visible.",
      "The goal is to make the product useful for both parties. Visitors should understand their next step and the people running the business should be able to see, manage and verify the outcome.",
      "## What you can actually try",
      "- **Editorial, filterable interior-collection gallery**",
      "- **Browser-local moodboard with saved styles**",
      "- **Consultation enquiry with owner-side collection management**",
      "## What is functional, and what is simulated?",
      "The forms, controls, filters and state transitions respond as described. All moodboards and enquiries stay in the same browser; nothing is emailed to the studio. Haven Interiors is a fictional portfolio brand, not a client testimonial. This is a demonstration of MCC’s design and implementation approach, not a claim of work completed for a named paying client or a verified uplift in revenue.",
      "## What MCC could build for your company",
      "A production version could include a content-management system, client accounts, a consultation inbox, workflow notifications and a secure dashboard that a real team can use.",
      "A real implementation begins with your existing operations: permissions, data retention, reliability, integration requirements, the customer experience and the points where a person must remain in control. MCC then scopes the right architecture before developing and testing a production system.",
      "## Explore the concept and request your own version",
      "Interactive demo: `[ADD THE VERIFIED MCC GITHUB PAGES URL BEFORE PUBLICATION]`",
      "Dutch companion article: `[ADD VERIFIED MCC ARTICLE URL BEFORE PUBLICATION]`",
      "Want a similar solution tailored to your business? DM CLONE to @mccai.nl and mention Haven Interiors. We’ll discuss what needs to be changed for your real workflow.",
      "*MCC — Make business easier.*"
    ],
    "draft": true
  },
  {
    "slug": "leadpilot",
    "title": "LeadPilot — MCC interactive concept",
    "date": "2026-10-29",
    "lang": "en",
    "summary": "A new website enquiry is a good start. But what happens next? If the only outcome is another email in a busy inbox, it is easy to lose track of customer requirements, callbacks and responsibiliti",
    "tags": [
      "Web apps",
      "Interactive demo",
      "MCC portfolio"
    ],
    "body": [
      "A new website enquiry is a good start. But what happens next? If the only outcome is another email in a busy inbox, it is easy to lose track of customer requirements, callbacks and responsibilities. LeadPilot is MCC's interactive concept for showing how a tailored web app can connect the customer journey with business operations.",
      "## The customer experience",
      "Visitors fill in a concise project brief, choose what they need (website, web application, automation or AI assistant), and optionally select budget and target timing. They receive a clear on-screen confirmation. The submitted test enquiry immediately appears on the owner side of the demo.",
      "## The owner's experience",
      "In the dashboard, business owners can review incoming requests, search the pipeline, change each lead's stage from *New* to *In discussion*, *Proposal* or *Won*, add private notes, create follow-up tasks, complete them, and inspect the activity history.",
      "The purpose is not to add yet another dashboard. It is to make the next meaningful action visible as soon as a request comes in.",
      "## Why tailor the application?",
      "Different organizations handle enquiries, projects, approvals and customer communications differently. MCC can design software around that workflow, with integrations chosen for the actual business case. A production application would also require authentication, permission checks, protected storage, secure APIs and privacy safeguards.",
      "## Try the demo",
      "Interactive LeadPilot demo: [add the verified MCC GitHub Pages link after publication]",
      "Switch between the *Customer* and *Owner* tabs and use fictional details to try the journey yourself.",
      "> **Demo disclosure:** LeadPilot currently runs on fictional example data, and submitted entries are stored in the local browser only. It is not connected to an email system or live CRM. The numbers displayed are sample counts, not real customer outcomes or measured results.",
      "## Want a customized version?",
      "MCC builds websites, business automations, web apps and AI assistants around your processes. DM CLONE to [@mccai.nl](https://www.instagram.com/mccai.nl/) to discuss a version designed for your organization.",
      "MCC — Make business simpler."
    ],
    "draft": true
  },
  {
    "slug": "pulse-studio",
    "title": "Pulse Studio — MCC interactive concept",
    "date": "2026-10-30",
    "lang": "en",
    "summary": "An MCC interactive portfolio concept · fictional brand and safe sample data",
    "tags": [
      "Websites",
      "Interactive demo",
      "MCC portfolio"
    ],
    "body": [
      "An MCC interactive portfolio concept · fictional brand and safe sample data",
      "## Why businesses need more than attractive interfaces",
      "Fitness members want to find the right class, see availability and book without making a call. Studio staff need the same booking data to see remaining spaces, attendance and class capacity. If those views are disconnected, everyone wastes time.",
      "## Try the customer experience and the owner’s perspective",
      "A customer browses classes with instructors and session times, sees the available spaces and reserves a fictional trial class. In the owner dashboard, the booking appears immediately: the team can mark attendance, cancel a booking or adjust capacity.",
      "The goal is to make the product useful for both parties. Visitors should understand their next step and the people running the business should be able to see, manage and verify the outcome.",
      "## What you can actually try",
      "- **A distinctive fitness-site experience with clearly described classes**",
      "- **Trial-class booking with available-capacity and duplicate-email checks**",
      "- **Owner view for bookings, attendance and class limits**",
      "## What is functional, and what is simulated?",
      "The forms, controls, filters and state transitions respond as described. The bookings exist only in this browser. No actual studio calendar, email reminder, membership charge or payment flow is connected. This is a demonstration of MCC’s design and implementation approach, not a claim of work completed for a named paying client or a verified uplift in revenue.",
      "## What MCC could build for your company",
      "For a real studio, MCC could implement memberships, recurring payments, scheduling and attendance tools, notifications, permission controls and a maintainable content-management workflow.",
      "A real implementation begins with your existing operations: permissions, data retention, reliability, integration requirements, the customer experience and the points where a person must remain in control. MCC then scopes the right architecture before developing and testing a production system.",
      "## Explore the concept and request your own version",
      "Interactive demo: `[ADD THE VERIFIED MCC GITHUB PAGES URL BEFORE PUBLICATION]`",
      "Dutch companion article: `[ADD VERIFIED MCC ARTICLE URL BEFORE PUBLICATION]`",
      "Want a similar solution tailored to your business? DM CLONE to @mccai.nl and mention Pulse Studio. We’ll discuss what needs to be changed for your real workflow.",
      "*MCC — Make business easier.*"
    ],
    "draft": true
  },
  {
    "slug": "vraagassistent",
    "title": "VraagAssistent — MCC interactive concept",
    "date": "2026-10-31",
    "lang": "en",
    "summary": "An MCC interactive portfolio concept · fictional brand and safe sample data",
    "tags": [
      "AI assistants",
      "Interactive demo",
      "MCC portfolio"
    ],
    "body": [
      "An MCC interactive portfolio concept · fictional brand and safe sample data",
      "## Why businesses need more than attractive interfaces",
      "Customer enquiries often arrive outside business hours, and staff spend time repeating the same information. An assistant can help with known facts, but should not improvise when it lacks a reliable answer. Knowing when to hand over is just as important as speed.",
      "## Try the customer experience and the owner’s perspective",
      "The visitor asks about opening hours, appointments or introduction prices. A small fixed knowledge base returns clearly scoped answers. Unknown questions become local demonstration tickets that the owner can review and mark as handled.",
      "The goal is to make the product useful for both parties. Visitors should understand their next step and the people running the business should be able to see, manage and verify the outcome.",
      "## What you can actually try",
      "- **Chat experience with concrete FAQ examples**",
      "- **A small, transparent knowledge base that avoids guessing**",
      "- **Escalation of unfamiliar enquiries to a human support queue**",
      "## What is functional, and what is simulated?",
      "The forms, controls, filters and state transitions respond as described. This is a deterministic support simulation, not a generative AI deployment. It has no live calendar, actual support agent, external API or customer data. This is a demonstration of MCC’s design and implementation approach, not a claim of work completed for a named paying client or a verified uplift in revenue.",
      "## What MCC could build for your company",
      "MCC can build a production assistant connected to verified knowledge, supervised business processes, consent-aware data handling and ticket systems, with explicit escalation and safety boundaries.",
      "A real implementation begins with your existing operations: permissions, data retention, reliability, integration requirements, the customer experience and the points where a person must remain in control. MCC then scopes the right architecture before developing and testing a production system.",
      "## Explore the concept and request your own version",
      "Interactive demo: `[ADD THE VERIFIED MCC GITHUB PAGES URL BEFORE PUBLICATION]`",
      "Dutch companion article: `[ADD VERIFIED MCC ARTICLE URL BEFORE PUBLICATION]`",
      "Want a similar solution tailored to your business? DM CLONE to @mccai.nl and mention VraagAssistent. We’ll discuss what needs to be changed for your real workflow.",
      "*MCC — Make business easier.*"
    ],
    "draft": true
  },
  {
    "slug": "rivier-coffee",
    "title": "Rivier Coffee — MCC interactive concept",
    "date": "2026-11-01",
    "lang": "en",
    "summary": "An MCC interactive portfolio concept · fictional brand and safe sample data",
    "tags": [
      "Websites",
      "Interactive demo",
      "MCC portfolio"
    ],
    "body": [
      "An MCC interactive portfolio concept · fictional brand and safe sample data",
      "## Why businesses need more than attractive interfaces",
      "When someone discovers a café, they want to see the atmosphere, check the menu on their phone and reserve a table without friction. If finding a dish or opening a reservation is difficult, the experience falls short before the customer has arrived.",
      "## Try the customer experience and the owner’s perspective",
      "A guest opens a mobile-friendly menu, filters coffee, breakfast and lunch and requests a fictional table reservation. The owner sees the request, can confirm or cancel it and can hide unavailable items from the guest-facing menu.",
      "The goal is to make the product useful for both parties. Visitors should understand their next step and the people running the business should be able to see, manage and verify the outcome.",
      "## What you can actually try",
      "- **Editorial café website with filterable mobile menu**",
      "- **Simple example table booking by date, time and party size**",
      "- **Owner controls for reservations and menu visibility**",
      "## What is functional, and what is simulated?",
      "The forms, controls, filters and state transitions respond as described. The menu and bookings are illustrative and remain in the same browser. There is no live point-of-sale system, table inventory or customer messaging. This is a demonstration of MCC’s design and implementation approach, not a claim of work completed for a named paying client or a verified uplift in revenue.",
      "## What MCC could build for your company",
      "MCC could connect live table availability, menu and opening-hour management, reservations, restaurant operations tools and guest notifications in a real deployment.",
      "A real implementation begins with your existing operations: permissions, data retention, reliability, integration requirements, the customer experience and the points where a person must remain in control. MCC then scopes the right architecture before developing and testing a production system.",
      "## Explore the concept and request your own version",
      "Interactive demo: `[ADD THE VERIFIED MCC GITHUB PAGES URL BEFORE PUBLICATION]`",
      "Dutch companion article: `[ADD VERIFIED MCC ARTICLE URL BEFORE PUBLICATION]`",
      "Want a similar solution tailored to your business? DM CLONE to @mccai.nl and mention Rivier Coffee. We’ll discuss what needs to be changed for your real workflow.",
      "*MCC — Make business easier.*"
    ],
    "draft": true
  },
  {
    "slug": "orderbridge",
    "title": "OrderBridge — MCC interactive concept",
    "date": "2026-11-02",
    "lang": "en",
    "summary": "An MCC interactive portfolio concept · fictional brand and safe sample data",
    "tags": [
      "Automation",
      "Interactive demo",
      "MCC portfolio"
    ],
    "body": [
      "An MCC interactive portfolio concept · fictional brand and safe sample data",
      "## Why businesses need more than attractive interfaces",
      "A contact form is not a follow-up system. New enquiries can sit in inboxes without an owner, an appropriate first response or a reminder. A useful automation translates a request into clearly assigned work while leaving critical approvals with people.",
      "## Try the customer experience and the owner’s perspective",
      "A visitor submits a project enquiry with a category and budget range. The demo creates a simulated CRM lead, assigns a sample team and prepares an email draft and follow-up task. The business owner can qualify the lead, review the draft and mark the task complete.",
      "The goal is to make the product useful for both parties. Visitors should understand their next step and the people running the business should be able to see, manage and verify the outcome.",
      "## What you can actually try",
      "- **Structured client enquiry instead of unstructured email**",
      "- **Local CRM record, example routing, reply draft and follow-up task**",
      "- **Owner controls for qualification, draft review and task status**",
      "## What is functional, and what is simulated?",
      "The forms, controls, filters and state transitions respond as described. There is no connection to a real CRM, messaging platform or mail server. No email is sent; all records are simulated in the browser. This is a demonstration of MCC’s design and implementation approach, not a claim of work completed for a named paying client or a verified uplift in revenue.",
      "## What MCC could build for your company",
      "For production, MCC could integrate the actual CRM and business email provider, add approval thresholds, secure ownership rules and monitoring, and record every automation decision.",
      "A real implementation begins with your existing operations: permissions, data retention, reliability, integration requirements, the customer experience and the points where a person must remain in control. MCC then scopes the right architecture before developing and testing a production system.",
      "## Explore the concept and request your own version",
      "Interactive demo: `[ADD THE VERIFIED MCC GITHUB PAGES URL BEFORE PUBLICATION]`",
      "Dutch companion article: `[ADD VERIFIED MCC ARTICLE URL BEFORE PUBLICATION]`",
      "Want a similar solution tailored to your business? DM CLONE to @mccai.nl and mention OrderBridge. We’ll discuss what needs to be changed for your real workflow.",
      "*MCC — Make business easier.*"
    ],
    "draft": true
  }
];

export const campaign2026DutchTranslations: Record<string, PostText> = {
  "marea-stay": {
    "title": "Marea Stay — interactieve MCC-conceptdemo",
    "summary": "Een mooie website is prettig. Maar voor een hotel is een website pas waardevol als gasten snel begrijpen wat ze kunnen verwachten én eenvoudig een verblijf kunnen boeken.",
    "tags": [
      "Interactieve demo",
      "MCC portfolio",
      "Websites"
    ],
    "body": [
      "Een mooie website is prettig. Maar voor een hotel is een website pas waardevol als gasten snel begrijpen wat ze kunnen verwachten én eenvoudig een verblijf kunnen boeken.",
      "Met Marea Stay maakte MCC een interactief voorbeeld van een boutique-hotelwebsite. Het is een volledig fictief hotelconcept, geen opdrachtgever of bestaand hotel. We laten er twee kanten mee zien: hoe een gast een kamer kiest en boekt, en hoe de hotelmedewerker die reservering verwerkt.",
      "## Het probleem: mooie kamers, onduidelijk boekingsproces",
      "Een reiziger vindt je hotel via Instagram of een zoekmachine. De sfeer spreekt aan, maar prijzen, beschikbaarheid en de volgende stap zijn lastig te vinden. De bezoeker moet eerst mailen, wachten of opnieuw zoeken. Dat is precies de frictie die een goed ontworpen boekingsroute moet wegnemen.",
      "Het doel is niet méér animatie. Het doel is: sneller vertrouwen opbouwen en een duidelijk pad bieden van interesse naar bevestiging.",
      "## Wat een gast kan doen in de interactieve demo",
      "In de Marea Stay-demo kun je:",
      "- drie verschillende suites bekijken, ieder met eigen capaciteit en prijs;",
      "- aankomst- en vertrekdata kiezen en het gezelschap instellen;",
      "- zien welke suite volgens de **gesimuleerde beschikbaarheid** past;",
      "- een voorbeeldreservering maken met een overzichtelijk totaalbedrag;",
      "- een lokaal reserveringsnummer ontvangen zonder betaling of e-mail.",
      "De interface is ontworpen voor zowel mobiel als desktop. De pagina vertelt eerst het verhaal van het verblijf en maakt boeken daarna snel bereikbaar.",
      "## Wat de eigenaar ziet",
      "Een hotelwebsite staat niet op zichzelf. Achter iedere reservering zit een operatie.",
      "Daarom bevat de demo ook een eigenaarsdashboard. Open bovenaan de website de knop *Eigenaar · Demo*. Daar verschijnen testreserveringen met kamer, datums, gezelschap en waarde. Je kunt een boeking op *Ingecheckt* zetten, annuleren en de voorbeeldgegevens resetten.",
      "Maak je aan de gastkant een nieuwe demo-reservering, dan verschijnt die direct in het dashboard van dezelfde browser. Dat laat de samenhang zien tussen de publieke website en het beheer.",
      "## Wat is echt werkend, en wat is alleen een demo?",
      "Werkend in dit concept: navigatie, kamerkeuze, datumvalidatie, eenvoudige beschikbaarheidscontrole, prijsberekening, bevestiging, statuswijzigingen en lokaal bewaarde voorbeeldboekingen.",
      "Niet aangesloten: een echte hotelvoorraad, een betaalprovider, e-mailbevestiging, een channel manager, een CRM of een gedeelde productie-database. De reserveringen worden uitsluitend in de browser van de bezoeker opgeslagen en vormen geen echte boekingen.",
      "Een productie-oplossing vraagt aanvullende beveiliging, server-side beschikbaarheidsbeheer, betalingen, privacymaatregelen en koppelingen met de software van het hotel.",
      "## Welke versie zou bij jouw bedrijf passen?",
      "MCC ontwikkelt websites en webapplicaties rondom de gewenste klantreis en de processen achter de schermen. Voor een hotel kan dat gaan van een eenvoudige aanvraagroute tot een volledige reserveringsintegratie. We beginnen met de bestaande systemen en met de vraag welke stappen werkelijk waarde toevoegen.",
      "Bekijk eerst de interactieve Marea Stay-demo: [Live demo — link toevoegen na deployment].",
      "Wil je een soortgelijke website of reserveringservaring voor je eigen bedrijf? Stuur `CLONE` via Instagram DM naar [@mccai.nl](https://www.instagram.com/mccai.nl/) en vertel welk type onderneming je hebt. MCC bespreekt graag wat er voor jou gebouwd kan worden.",
      "*Marea Stay is een fictieve portfolio-demo van MCC. Alle namen, kamers, prijzen en reserveringen zijn voorbeelddata.*"
    ]
  },
  "factuurflow": {
    "title": "FactuurFlow — interactieve MCC-conceptdemo",
    "summary": "Een interactieve portfolio-conceptdemo van MCC · fictieve onderneming en voorbeelddata",
    "tags": [
      "Interactieve demo",
      "MCC portfolio",
      "Automatisering"
    ],
    "body": [
      "Een interactieve portfolio-conceptdemo van MCC · fictieve onderneming en voorbeelddata",
      "## Het probleem: waarom dit belangrijk is",
      "Bij handmatige factuurverwerking worden regels, bedragen en leveranciers telkens opnieuw overgenomen. Fouten vallen soms pas veel later op. Automatisering moet juist inzicht geven in uitzonderingen.",
      "## Van bezoeker naar ondernemer: probeer beide kanten",
      "De gebruiker kiest een veilige voorbeeldfactuur. De demo controleert de bekende regels en het bedrag en markeert een afwijkend totaal. In het eigenaarsdashboard corrigeert de ondernemer de invoer en keurt die pas goed nadat de controle slaagt.",
      "De bezoeker hoeft niet te weten hoe alle techniek werkt. De eigenaar moet juist wel kunnen zien wat er gebeurt. Die twee perspectieven tonen we in deze interactieve demonstratie, met controleerbare stappen die je zelf kunt uitproberen.",
      "## Wat kun je proberen in de demo?",
      "- **Factuurintake met vooraf gedefinieerde demo-data**.",
      "- **Herberekening en automatische afwijkingssignalering**.",
      "- **Menselijke correctie, goedkeuring en auditlog**.",
      "## Wat is echt werkend — en wat nog niet?",
      "De knoppen, formulieren, filters en statussen van de voorbeeldapplicatie reageren daadwerkelijk. Dit is een deterministische simulatie: geen live OCR, geen echte boekhoudsoftware, geen financiële mutaties. We claimen geen bestaand klantproject, live koppelingen of gemeten omzetverbetering. Zo kun je zien wat de oplossing *kan* doen, zonder dat wij een simulatie als een volledig product verkopen.",
      "## Wat zou MCC voor jouw bedrijf bouwen?",
      "In productie kan MCC beveiligde documentextractie, leverancierschecks, btw-regels, ERP-integraties en goedkeuringsrechten bouwen.",
      "De productieversie begint met een gesprek over jouw echte processen: welke klanten gebruikmaken van het systeem, wie eigenaar is van de data, wat geautomatiseerd mag worden, en waar je bewust menselijke controle wilt. Daarna bepalen we samen de technische scope, mobiele ervaring en koppelingen.",
      "## Bekijk het project en bespreek jouw variant",
      "Interactieve demo: `[DEFINITIEVE MCC GITHUB PAGES URL NA LIVE CONTROLE]`",
      "Dit artikel: `[DEFINITIEVE MCC BLOG URL NA PUBLICATIE]`",
      "Wil je een vergelijkbare oplossing voor jouw onderneming? Stuur CLONE via Instagram DM naar @mccai.nl, met de naam FactuurFlow. We bespreken hoe we het passend maken voor jouw merk en processen.",
      "*MCC — Maak ondernemen eenvoudiger.*"
    ]
  },
  "haven-interiors": {
    "title": "Haven Interiors — interactieve MCC-conceptdemo",
    "summary": "Een interactieve portfolio-conceptdemo van MCC · fictieve onderneming en voorbeelddata",
    "tags": [
      "Interactieve demo",
      "MCC portfolio",
      "Websites"
    ],
    "body": [
      "Een interactieve portfolio-conceptdemo van MCC · fictieve onderneming en voorbeelddata",
      "## Het probleem: waarom dit belangrijk is",
      "Een interieurstudio heeft veel te laten zien, maar potentiële klanten willen ook hun smaak kunnen verzamelen en precies aangeven wat zij zoeken. Een statische galerij laat te vaak onduidelijkheid achter.",
      "## Van bezoeker naar ondernemer: probeer beide kanten",
      "Een bezoeker filtert woonruimtes, bewaart favoriete stijlen op een lokaal moodboard en stuurt een conceptaanvraag. De studio-eigenaar ziet welke stijlen de klant koos, markeert de aanvraag als opgevolgd en kan collectie-items verbergen.",
      "De bezoeker hoeft niet te weten hoe alle techniek werkt. De eigenaar moet juist wel kunnen zien wat er gebeurt. Die twee perspectieven tonen we in deze interactieve demonstratie, met controleerbare stappen die je zelf kunt uitproberen.",
      "## Wat kun je proberen in de demo?",
      "- **Editorial collectiegalerij met categorieën**.",
      "- **Persoonlijk moodboard met bewaarde stijlen**.",
      "- **Intake voor advies plus beheer van zichtbaarheid**.",
      "## Wat is echt werkend — en wat nog niet?",
      "De knoppen, formulieren, filters en statussen van de voorbeeldapplicatie reageren daadwerkelijk. Moodboards en aanvragen worden alleen lokaal in de browser bijgehouden. Er wordt geen bericht verstuurd; de fictieve studio is geen echte klant. We claimen geen bestaand klantproject, live koppelingen of gemeten omzetverbetering. Zo kun je zien wat de oplossing *kan* doen, zonder dat wij een simulatie als een volledig product verkopen.",
      "## Wat zou MCC voor jouw bedrijf bouwen?",
      "MCC kan dit uitbouwen met een beheersysteem, klantportaal, e-mailintake en echte contentworkflow.",
      "De productieversie begint met een gesprek over jouw echte processen: welke klanten gebruikmaken van het systeem, wie eigenaar is van de data, wat geautomatiseerd mag worden, en waar je bewust menselijke controle wilt. Daarna bepalen we samen de technische scope, mobiele ervaring en koppelingen.",
      "## Bekijk het project en bespreek jouw variant",
      "Interactieve demo: `[DEFINITIEVE MCC GITHUB PAGES URL NA LIVE CONTROLE]`",
      "Dit artikel: `[DEFINITIEVE MCC BLOG URL NA PUBLICATIE]`",
      "Wil je een vergelijkbare oplossing voor jouw onderneming? Stuur CLONE via Instagram DM naar @mccai.nl, met de naam Haven Interiors. We bespreken hoe we het passend maken voor jouw merk en processen.",
      "*MCC — Maak ondernemen eenvoudiger.*"
    ]
  },
  "leadpilot": {
    "title": "LeadPilot — interactieve MCC-conceptdemo",
    "summary": "Een nieuwe klantaanvraag is vaak een goed begin — maar wat gebeurt er daarna? Een contactformulier dat alleen een e-mail verstuurt, kan zorgen voor losse notities, vergeten terugbelmomenten en on",
    "tags": [
      "Interactieve demo",
      "MCC portfolio",
      "Webapplicaties"
    ],
    "body": [
      "Een nieuwe klantaanvraag is vaak een goed begin — maar wat gebeurt er daarna? Een contactformulier dat alleen een e-mail verstuurt, kan zorgen voor losse notities, vergeten terugbelmomenten en onduidelijkheid over wie wat oppakt. Precies dat dagelijkse probleem staat centraal in ons conceptproject LeadPilot.",
      "Met LeadPilot laten we zien hoe MCC een webapplicatie op maat kan ontwikkelen: één ervaring voor degene die contact opneemt en een compleet andere, maar verbonden ervaring voor de ondernemer die de aanvraag moet opvolgen.",
      "## De klantkant: duidelijk en toegankelijk",
      "In de voorbeeldwebsite beschrijft een bezoeker het project, kiest hij of zij de gewenste dienst — website, webapp, automatisering of AI-assistent — en vult optioneel budget en gewenste start in. Na het indienen verschijnt een bevestiging. Er is geen ingewikkelde intakeprocedure nodig om interesse kenbaar te maken.",
      "De ingezonden testaanvraag verschijnt direct in het eigenaarsoverzicht. Daarmee wordt het verschil zichtbaar tussen een formulier dat gegevens verzamelt en een proces dat de volgende stap organiseert.",
      "## De ondernemerskant: overzicht en opvolging",
      "In de LeadPilot demo kan de ondernemer:",
      "- binnengekomen aanvragen bekijken en doorzoeken;",
      "- een project van *Nieuw* naar *In gesprek*, *Voorstel* of *Gewonnen* verplaatsen;",
      "- contactgegevens, dienst, budget en projectomschrijving teruglezen;",
      "- interne notities toevoegen, aanpassen en bewaren;",
      "- gerichte opvolgtaken aanmaken en afvinken;",
      "- wijzigingen terugzien in de activiteitengeschiedenis.",
      "De belangrijkste boodschap is niet dat je nóg een dashboard nodig hebt. Het gaat erom dat de volgende concrete actie niet verloren gaat zodra een klant op 'Versturen' klikt.",
      "## Waarom een webapp op maat?",
      "Een organisatie heeft vaak een unieke combinatie van aanvragen, klantinformatie, interne processen en afspraken. Met een passende webapp kan MCC die stappen rondom het bedrijf organiseren in plaats van het bedrijf te dwingen zich aan te passen aan een standaardtool.",
      "Denk aan een projectstudio die meerdere diensten aanbiedt, een installatiebedrijf dat offertes voorbereidt, of een creatief bureau met een klein team. Welke functies daarbij echt nodig zijn, bepalen we samen op basis van werkprocessen, privacy, kosten en bestaande systemen.",
      "## Probeer de interactieve conceptdemo",
      "Interactieve LeadPilot demo: [wordt ingevuld na publicatie op MCC GitHub Pages]",
      "De demo heeft twee tabbladen: Voor de klant en Voor de ondernemer. Gebruik gerust fictieve gegevens om zelf te ervaren hoe één aanvraag zichtbaar wordt in de pijplijn.",
      "> **Transparantie:** LeadPilot is op dit moment een interactieve conceptdemo met fictieve gegevens. Nieuwe testaanvragen worden alleen in de eigen browser bewaard. Er worden geen echte e-mails verzonden, geen externe CRM-systemen aangeroepen en geen persoonlijke gegevens verwerkt op onze server. Resultaten op het scherm zijn geen claims over echte klanten of gerealiseerde besparingen.",
      "## Een vergelijkbaar systeem voor jouw bedrijf?",
      "MCC bouwt websites, webapplicaties en automatiseringen die bij echte werkwijzen passen. Wil je een eigen versie van dit concept — met jouw formulieren, rollen en bedrijfsprocessen? Stuur CLONE via Instagram DM naar [@mccai.nl](https://www.instagram.com/mccai.nl/). We bespreken graag de mogelijkheden en wat er nodig is voor een veilige productieversie.",
      "MCC — Maak ondernemen eenvoudiger."
    ]
  },
  "pulse-studio": {
    "title": "Pulse Studio — interactieve MCC-conceptdemo",
    "summary": "Een interactieve portfolio-conceptdemo van MCC · fictieve onderneming en voorbeelddata",
    "tags": [
      "Interactieve demo",
      "MCC portfolio",
      "Websites"
    ],
    "body": [
      "Een interactieve portfolio-conceptdemo van MCC · fictieve onderneming en voorbeelddata",
      "## Het probleem: waarom dit belangrijk is",
      "Een sportstudio krijgt vragen over tijden, beschikbare plekken en inschrijvingen. Zonder gekoppelde boekingsreis is elk verzoek een extra taak voor het team.",
      "## Van bezoeker naar ondernemer: probeer beide kanten",
      "De sporter bekijkt lessen met trainer, tijd en resterende capaciteit en boekt een fictieve proefles. In de eigenaarweergave verschijnt de inschrijving en kan een beheerder aanwezigheid markeren, annuleren of lescapaciteit aanpassen.",
      "De bezoeker hoeft niet te weten hoe alle techniek werkt. De eigenaar moet juist wel kunnen zien wat er gebeurt. Die twee perspectieven tonen we in deze interactieve demonstratie, met controleerbare stappen die je zelf kunt uitproberen.",
      "## Wat kun je proberen in de demo?",
      "- **Sportieve editorial website met onderscheidende lessen**.",
      "- **Proeflesboeking met capaciteit en dubbele-inschrijvingcontrole**.",
      "- **Rooster, aanmeldingen en eigenaarbeheer**.",
      "## Wat is echt werkend — en wat nog niet?",
      "De knoppen, formulieren, filters en statussen van de voorbeeldapplicatie reageren daadwerkelijk. Alle reserveringen zijn browserlokale demo-data. Geen betalingen, live studioagenda of echte berichten. We claimen geen bestaand klantproject, live koppelingen of gemeten omzetverbetering. Zo kun je zien wat de oplossing *kan* doen, zonder dat wij een simulatie als een volledig product verkopen.",
      "## Wat zou MCC voor jouw bedrijf bouwen?",
      "MCC kan een echte studiowebsite bouwen met lidmaatschappen, agenda-koppelingen, betaalstromen en aanwezigheidsoverzicht.",
      "De productieversie begint met een gesprek over jouw echte processen: welke klanten gebruikmaken van het systeem, wie eigenaar is van de data, wat geautomatiseerd mag worden, en waar je bewust menselijke controle wilt. Daarna bepalen we samen de technische scope, mobiele ervaring en koppelingen.",
      "## Bekijk het project en bespreek jouw variant",
      "Interactieve demo: `[DEFINITIEVE MCC GITHUB PAGES URL NA LIVE CONTROLE]`",
      "Dit artikel: `[DEFINITIEVE MCC BLOG URL NA PUBLICATIE]`",
      "Wil je een vergelijkbare oplossing voor jouw onderneming? Stuur CLONE via Instagram DM naar @mccai.nl, met de naam Pulse Studio. We bespreken hoe we het passend maken voor jouw merk en processen.",
      "*MCC — Maak ondernemen eenvoudiger.*"
    ]
  },
  "vraagassistent": {
    "title": "VraagAssistent — interactieve MCC-conceptdemo",
    "summary": "Een interactieve portfolio-conceptdemo van MCC · fictieve onderneming en voorbeelddata",
    "tags": [
      "Interactieve demo",
      "MCC portfolio",
      "AI-assistenten"
    ],
    "body": [
      "Een interactieve portfolio-conceptdemo van MCC · fictieve onderneming en voorbeelddata",
      "## Het probleem: waarom dit belangrijk is",
      "Veel klantvragen komen buiten kantooruren binnen. Een assistent kan helpen met bekende bedrijfsinformatie, maar moet bij onzekerheid niet improviseren. Vertrouwen en menselijke overdracht zijn essentieel.",
      "## Van bezoeker naar ondernemer: probeer beide kanten",
      "De bezoeker stelt een vraag over openingstijden, tarieven of afspraken. De kleine vaste kennisbank geeft een begrensd voorbeeldantwoord. Een onbekende vraag wordt een supportticket dat de eigenaar in de demo kan behandelen.",
      "De bezoeker hoeft niet te weten hoe alle techniek werkt. De eigenaar moet juist wel kunnen zien wat er gebeurt. Die twee perspectieven tonen we in deze interactieve demonstratie, met controleerbare stappen die je zelf kunt uitproberen.",
      "## Wat kun je proberen in de demo?",
      "- **Chatinterface met concrete veelgestelde vragen**.",
      "- **Beperkte, transparante en controleerbare kennisbank**.",
      "- **Escalatie van onbekende vragen naar een medewerker**.",
      "## Wat is echt werkend — en wat nog niet?",
      "De knoppen, formulieren, filters en statussen van de voorbeeldapplicatie reageren daadwerkelijk. Dit is geen live generatief AI-model. Het gebruikt vaste demo-antwoorden en lokale tickets; geen reserveringen, echte e-mails of bedrijfskoppelingen. We claimen geen bestaand klantproject, live koppelingen of gemeten omzetverbetering. Zo kun je zien wat de oplossing *kan* doen, zonder dat wij een simulatie als een volledig product verkopen.",
      "## Wat zou MCC voor jouw bedrijf bouwen?",
      "MCC kan dit koppelen aan geverifieerde kennisbronnen, menselijk toezicht, ticketing en veilige acties.",
      "De productieversie begint met een gesprek over jouw echte processen: welke klanten gebruikmaken van het systeem, wie eigenaar is van de data, wat geautomatiseerd mag worden, en waar je bewust menselijke controle wilt. Daarna bepalen we samen de technische scope, mobiele ervaring en koppelingen.",
      "## Bekijk het project en bespreek jouw variant",
      "Interactieve demo: `[DEFINITIEVE MCC GITHUB PAGES URL NA LIVE CONTROLE]`",
      "Dit artikel: `[DEFINITIEVE MCC BLOG URL NA PUBLICATIE]`",
      "Wil je een vergelijkbare oplossing voor jouw onderneming? Stuur CLONE via Instagram DM naar @mccai.nl, met de naam VraagAssistent. We bespreken hoe we het passend maken voor jouw merk en processen.",
      "*MCC — Maak ondernemen eenvoudiger.*"
    ]
  },
  "rivier-coffee": {
    "title": "Rivier Coffee — interactieve MCC-conceptdemo",
    "summary": "Een interactieve portfolio-conceptdemo van MCC · fictieve onderneming en voorbeelddata",
    "tags": [
      "Interactieve demo",
      "MCC portfolio",
      "Websites"
    ],
    "body": [
      "Een interactieve portfolio-conceptdemo van MCC · fictieve onderneming en voorbeelddata",
      "## Het probleem: waarom dit belangrijk is",
      "Mensen willen snel een sfeer proeven, de menukaart bekijken en weten of er plek is. Bij een rommelige mobiele website grijpen ze naar de telefoon of zoeken ze een ander café.",
      "## Van bezoeker naar ondernemer: probeer beide kanten",
      "De gast opent een sfeervolle menukaart, filtert koffie, ontbijt of lunch en plaatst een fictieve tafelreservering. De eigenaar ziet de aanvraag, kan haar bevestigen of annuleren en beheert of menu-items beschikbaar zijn.",
      "De bezoeker hoeft niet te weten hoe alle techniek werkt. De eigenaar moet juist wel kunnen zien wat er gebeurt. Die twee perspectieven tonen we in deze interactieve demonstratie, met controleerbare stappen die je zelf kunt uitproberen.",
      "## Wat kun je proberen in de demo?",
      "- **Redactionele cafépresentatie met mobiele menukaart**.",
      "- **Eenvoudige conceptreservering op datum en tijd**.",
      "- **Eigenaarsoverzicht voor tafels en menubeschikbaarheid**.",
      "## Wat is echt werkend — en wat nog niet?",
      "De knoppen, formulieren, filters en statussen van de voorbeeldapplicatie reageren daadwerkelijk. De menukaart en boekingen zijn fictieve browser-lokale data. Er is geen live POS-, reserverings- of e-mailkoppeling. We claimen geen bestaand klantproject, live koppelingen of gemeten omzetverbetering. Zo kun je zien wat de oplossing *kan* doen, zonder dat wij een simulatie als een volledig product verkopen.",
      "## Wat zou MCC voor jouw bedrijf bouwen?",
      "MCC kan een echte horecabeleving koppelen aan tafelbeheer, actuele openingstijden, kaartbeheer en reserveringsmeldingen.",
      "De productieversie begint met een gesprek over jouw echte processen: welke klanten gebruikmaken van het systeem, wie eigenaar is van de data, wat geautomatiseerd mag worden, en waar je bewust menselijke controle wilt. Daarna bepalen we samen de technische scope, mobiele ervaring en koppelingen.",
      "## Bekijk het project en bespreek jouw variant",
      "Interactieve demo: `[DEFINITIEVE MCC GITHUB PAGES URL NA LIVE CONTROLE]`",
      "Dit artikel: `[DEFINITIEVE MCC BLOG URL NA PUBLICATIE]`",
      "Wil je een vergelijkbare oplossing voor jouw onderneming? Stuur CLONE via Instagram DM naar @mccai.nl, met de naam Rivier Coffee. We bespreken hoe we het passend maken voor jouw merk en processen.",
      "*MCC — Maak ondernemen eenvoudiger.*"
    ]
  },
  "orderbridge": {
    "title": "OrderBridge — interactieve MCC-conceptdemo",
    "summary": "Een interactieve portfolio-conceptdemo van MCC · fictieve onderneming en voorbeelddata",
    "tags": [
      "Interactieve demo",
      "MCC portfolio",
      "Automatisering"
    ],
    "body": [
      "Een interactieve portfolio-conceptdemo van MCC · fictieve onderneming en voorbeelddata",
      "## Het probleem: waarom dit belangrijk is",
      "Nieuwe aanvragen blijven vaak in mailboxen hangen. Wie neemt ze op, welk antwoord is passend en wanneer volgt iemand op? Zonder systeem ontstaat tijdverlies en onduidelijkheid.",
      "## Van bezoeker naar ondernemer: probeer beide kanten",
      "De bezoeker vult een concreet projectverzoek in. De simulatie maakt een CRM-lead, kiest een voorbeeldteam en bereidt een e-mailconcept met opvolgtaak voor. De ondernemer beoordeelt het concept en kan de lead kwalificeren en de taak afvinken.",
      "De bezoeker hoeft niet te weten hoe alle techniek werkt. De eigenaar moet juist wel kunnen zien wat er gebeurt. Die twee perspectieven tonen we in deze interactieve demonstratie, met controleerbare stappen die je zelf kunt uitproberen.",
      "## Wat kun je proberen in de demo?",
      "- **Korte gestructureerde klantintake**.",
      "- **Automatische routing, conceptantwoord en taken**.",
      "- **Eigenaarcontrole over pipeline en vervolgacties**.",
      "## Wat is echt werkend — en wat nog niet?",
      "De knoppen, formulieren, filters en statussen van de voorbeeldapplicatie reageren daadwerkelijk. Geen echt CRM, geen e-mailversturing, geen externe teamtoewijzing. Het betreft lokale gesimuleerde records. We claimen geen bestaand klantproject, live koppelingen of gemeten omzetverbetering. Zo kun je zien wat de oplossing *kan* doen, zonder dat wij een simulatie als een volledig product verkopen.",
      "## Wat zou MCC voor jouw bedrijf bouwen?",
      "MCC kan dit inzetten op echte websites met CRM-API’s, veilig rechtenbeheer, leadkwalificatie en passende opvolgautomatiseringen.",
      "De productieversie begint met een gesprek over jouw echte processen: welke klanten gebruikmaken van het systeem, wie eigenaar is van de data, wat geautomatiseerd mag worden, en waar je bewust menselijke controle wilt. Daarna bepalen we samen de technische scope, mobiele ervaring en koppelingen.",
      "## Bekijk het project en bespreek jouw variant",
      "Interactieve demo: `[DEFINITIEVE MCC GITHUB PAGES URL NA LIVE CONTROLE]`",
      "Dit artikel: `[DEFINITIEVE MCC BLOG URL NA PUBLICATIE]`",
      "Wil je een vergelijkbare oplossing voor jouw onderneming? Stuur CLONE via Instagram DM naar @mccai.nl, met de naam OrderBridge. We bespreken hoe we het passend maken voor jouw merk en processen.",
      "*MCC — Maak ondernemen eenvoudiger.*"
    ]
  }
};
