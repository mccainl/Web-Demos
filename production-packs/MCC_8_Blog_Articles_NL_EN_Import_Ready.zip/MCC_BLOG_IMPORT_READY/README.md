# MCC v3 — Campaign blog import (STAGED, not live)

Source for eight **English articles with complete Dutch translations**, structured for the existing Next.js MCC blog architecture at `lib/v3/content/blog.ts` and `lib/v3/content/blog-translations.ts`.

1. Copy `campaign-2026-10-26.ts` to `lib/v3/content/campaign-2026-10-26.ts` in the MCC app repo.
2. In `blog.ts`, add `import { campaign2026Posts } from "./campaign-2026-10-26";` and include `...campaign2026Posts` as part of `ALL` (without deleting any existing posts).
3. In `blog-translations.ts`, import `campaign2026DutchTranslations` and merge each Dutch entry into the existing `translations` export. Keep fallback-to-English disclosures for locales without translations.
4. **IMPORTANT: All eight new posts have `draft: true`.** Keep them hidden until the corresponding MCC-owned GitHub Pages demos have been deployed, opened and tested. Then insert the verified demo URL in the article body, cross-link from the demo, set `draft: false`, run `lint/typecheck/build`, get publication authorization, deploy MCC v3 and open each final article URL.
5. Never publish placeholder links or mark these articles as live because code was committed.

All sample brands are fictional, and no live CRM, AI, payment, booking, accounting or email integrations are claimed.
